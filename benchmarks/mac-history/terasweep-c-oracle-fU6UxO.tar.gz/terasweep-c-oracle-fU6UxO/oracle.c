
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#define NOINLINE __attribute__((noinline))
#define ALWAYS __attribute__((always_inline)) inline
typedef struct { size_t n; uint8_t *tradable; double *entry,*cont; } Prices;
typedef struct {
 uint64_t signal_count; double eq_gross; int32_t entry_count,exit_count;
 uint64_t sharpe_count,cat_count[4]; double cat_sum_a[4],cat_sum_a2[4];
} Base;
static ALWAYS int active(double p,double t,int rule) {switch(rule){case 0:return p>t;case 1:return p>=t;case 2:return p<t;case 3:return p<=t;case 4:return fabs(p)>t;case 5:return fabs(p)>=t;default:abort();}}
NOINLINE static Base reference(const double*pred,double threshold,int rule,const Prices*p) {
 size_t n=p->n;Base b={.eq_gross=1.};for(size_t i=0;i<n;i++)if(active(pred[i],threshold,rule))b.signal_count++;
 int prev=0;for(size_t i=0;i<n;i++){
  int pos=i>0&&p->tradable[i]?active(pred[i-1],threshold,rule):0;
  int next=i+1<n&&p->tradable[i+1]?active(pred[i],threshold,rule):0;
  int entry=pos&&!prev,cont=pos&&prev,exit=pos&&!next;double gross=0.;
  if(entry){gross+=p->entry[i];b.entry_count++;}if(cont)gross+=p->cont[i];if(exit)b.exit_count++;
  double a=1.+gross;b.eq_gross*=a;if(i>0&&p->tradable[i]){int cat=entry|(exit<<1);b.sharpe_count++;b.cat_count[cat]++;b.cat_sum_a[cat]+=a;b.cat_sum_a2[cat]+=a*a;}prev=pos;
 }return b;
}
static uint64_t bits(double x){uint64_t b;memcpy(&b,&x,8);return b;}
static void read_exact(FILE*f,void*p,size_t n){assert(fread(p,1,n,f)==n);}
static void *alloc(size_t n,size_t z){void*p=calloc(n,z);assert(p);return p;}
int main(int argc,char**argv){assert(argc==2);FILE*f=fopen(argv[1],"rb");assert(f);uint64_t n,models;read_exact(f,&n,8);Prices p={n,alloc(n,1),alloc(n,8),alloc(n,8)};read_exact(f,p.tradable,n);read_exact(f,p.entry,n*8);read_exact(f,p.cont,n*8);read_exact(f,&models,8);double**preds=alloc(models,sizeof(double*));
 for(size_t i=0;i<models;i++){uint64_t len;read_exact(f,&len,8);if(len){assert(len==n);preds[i]=alloc(len,8);read_exact(f,preds[i],len*8);}}
 size_t checked=0;uint64_t idx;while(fread(&idx,8,1,f)==1){uint64_t rule,want[17],got[17];double t;read_exact(f,&rule,8);read_exact(f,&t,8);read_exact(f,want,sizeof want);assert(idx<models&&preds[idx]);Base b=reference(preds[idx],t,rule,&p);got[0]=b.signal_count;got[1]=bits(b.eq_gross);got[2]=b.entry_count;got[3]=b.exit_count;got[4]=b.sharpe_count;
 for(int k=0;k<4;k++){got[5+k]=b.cat_count[k];got[9+k]=bits(b.cat_sum_a[k]);got[13+k]=bits(b.cat_sum_a2[k]);}for(int k=0;k<17;k++)if(got[k]!=want[k]){fprintf(stderr,"Mismatch job=%zu model=%llu rule=%llu field=%d\n",checked,(unsigned long long)idx,(unsigned long long)rule,k);return 1;}checked++;}
 assert(feof(f));fclose(f);printf("C reference equals original Rust bit-for-bit: %zu complete BaseScores, all 17 fields each\n",checked);return 0;}
