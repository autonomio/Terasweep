use crate::results::{BaseScore, PriceStats, ScoreConfig};
#[derive(Clone, Copy)]
pub struct Job { pub train: usize, pub slot: usize, pub score: ScoreConfig }
#[cfg(all(target_arch="x86_64",target_os="linux"))]
#[repr(C)]
struct KernelPrices { n:usize, tradable:*const bool, entry:*const f64, cont:*const f64 }
#[cfg(all(target_arch="x86_64",target_os="linux"))]
#[repr(C)]
struct Packed8 { threshold:[f64;8],sign_xor:[u64;8],abs_and:[u64;8],inclusive:u64 }
#[cfg(all(target_arch="x86_64",target_os="linux"))]
#[repr(C)]
struct Raw8 { signal:[u64;8],equity:[f64;8],count:[[u64;8];4],sum:[[f64;8];4],square:[[f64;8];4],sharpe:u64 }
pub fn available(assembly:bool)->bool {
 #[cfg(all(target_arch="x86_64",target_os="linux"))]
 {std::is_x86_feature_detected!("avx512f") && (!assembly || std::is_x86_feature_detected!("bmi1"))}
 #[cfg(not(all(target_arch="x86_64",target_os="linux")))]
 {let _=assembly;false}
}
#[cfg(all(target_arch="x86_64",target_os="linux"))]
pub fn batch(pred:&[f64],prices:&PriceStats,jobs:&[Job],assembly:bool)->Vec<BaseScore> {
 assert!(!jobs.is_empty() && jobs.len()<=8);
 assert_eq!(pred.len(),prices.tradable.len());assert_eq!(pred.len(),prices.r_entry.len());assert_eq!(pred.len(),prices.r_cont.len());
 assert!(available(assembly),"requested AVX-512 backend is unavailable");
 let pz=KernelPrices{n:pred.len(),tradable:prices.tradable.as_ptr(),entry:prices.r_entry.as_ptr(),cont:prices.r_cont.as_ptr()};
 let mut packed=Packed8{threshold:[0.0;8],sign_xor:[0;8],abs_and:[u64::MAX;8],inclusive:0};
 for(lane,job)in jobs.iter().enumerate(){let r=job.score.signal_rule.index();
  packed.threshold[lane]=if r==2||r==3{-job.score.threshold}else{job.score.threshold};
  if r==2||r==3{packed.sign_xor[lane]=1<<63;}if r==4||r==5{packed.abs_and[lane]=!(1<<63);}
  if r%2==1{packed.inclusive|=1<<lane;}
 }
 let mut output=Raw8{signal:[0;8],equity:[0.0;8],count:[[0;8];4],sum:[[0.0;8];4],square:[[0.0;8];4],sharpe:0};
 #[cfg(all(target_arch="x86_64",target_os="linux"))]
 unsafe{
  // Feature detection, matched lengths and repr(C) layouts establish the kernel preconditions.
  if assembly{score8_asm_gpr(pred.as_ptr(),&pz,&packed,&mut output);}
  else{score8_intrinsics(pred.as_ptr(),&pz,&packed,&mut output);}
 }
 (0..jobs.len()).map(|lane|BaseScore{
  signal_count:output.signal[lane] as usize,eq_gross:output.equity[lane],
  entry_count:(output.count[1][lane]+output.count[3][lane])as i32,
  exit_count:(output.count[2][lane]+output.count[3][lane])as i32,sharpe_count:output.sharpe as usize,
  cat_count:std::array::from_fn(|c|output.count[c][lane] as usize),
  cat_sum_a:std::array::from_fn(|c|output.sum[c][lane]),cat_sum_a2:std::array::from_fn(|c|output.square[c][lane])
 }).collect()
}
#[cfg(all(target_arch="x86_64",target_os="linux"))]
core::arch::global_asm!(include_str!("score8_gpr.S"),options(raw));
#[cfg(all(target_arch="x86_64",target_os="linux"))]
extern "C"{fn score8_asm_gpr(pred:*const f64,prices:*const KernelPrices,rules:*const Packed8,out:*mut Raw8);}
#[cfg(all(target_arch="x86_64",target_os="linux"))]
#[target_feature(enable="avx512f")]
#[inline(never)]
#[no_mangle]
unsafe extern "C" fn score8_intrinsics(pred:*const f64,pz:&KernelPrices,r:&Packed8,out:&mut Raw8){
 use std::arch::x86_64::*;
 let zero=_mm512_setzero_pd();let one=_mm512_set1_pd(1.0);let oi=_mm512_set1_epi64(1);
 let t=_mm512_loadu_pd(r.threshold.as_ptr());
 let sx=_mm512_loadu_si512(r.sign_xor.as_ptr().cast());let ab=_mm512_loadu_si512(r.abs_and.as_ptr().cast());
 let inc=r.inclusive as __mmask8;
 let mut eq=one;let mut sums=[zero;4];let mut squares=[zero;4];let mut sigcnt=_mm512_setzero_si512();let mut nc=[sigcnt;4];
 let(mut last,mut prev):(__mmask8,__mmask8)=(0,0);let mut sharpe=0;
 for i in 0..pz.n{
  let pv=_mm512_castpd_si512(_mm512_set1_pd(*pred.add(i)));
  let pv=_mm512_and_si512(_mm512_xor_si512(pv,sx),ab);
  let sig=_mm512_cmp_pd_mask::<_CMP_GT_OQ>(_mm512_castsi512_pd(pv),t)
   |_mm512_mask_cmp_pd_mask::<_CMP_EQ_OQ>(inc,_mm512_castsi512_pd(pv),t);
  sigcnt=_mm512_mask_add_epi64(sigcnt,sig,sigcnt,oi);
  let pos=if i>0&&*pz.tradable.add(i){last}else{0};
  let nextpos=if i+1<pz.n&&*pz.tradable.add(i+1){sig}else{0};
  let en=(!prev)&pos;let co=prev&pos;let ex=(!nextpos)&pos;
  let gross=_mm512_mask_add_pd(zero,en,zero,_mm512_set1_pd(*pz.entry.add(i)));
  let gross=_mm512_mask_add_pd(gross,co,gross,_mm512_set1_pd(*pz.cont.add(i)));
  let a=_mm512_add_pd(one,gross);eq=_mm512_mul_pd(eq,a);
  if i>0&&*pz.tradable.add(i){sharpe+=1;let aa=_mm512_mul_pd(a,a);
   let masks=[!(en|ex),(!ex)&en,(!en)&ex,en&ex];
   for c in 0..4{nc[c]=_mm512_mask_add_epi64(nc[c],masks[c],nc[c],oi);
    sums[c]=_mm512_mask_add_pd(sums[c],masks[c],sums[c],a);
    squares[c]=_mm512_mask_add_pd(squares[c],masks[c],squares[c],aa);}
  }
  prev=pos;last=sig;
 }
 _mm512_storeu_si512(out.signal.as_mut_ptr().cast(),sigcnt);_mm512_storeu_pd(out.equity.as_mut_ptr(),eq);
 for c in 0..4{_mm512_storeu_si512(out.count[c].as_mut_ptr().cast(),nc[c]);
  _mm512_storeu_pd(out.sum[c].as_mut_ptr(),sums[c]);_mm512_storeu_pd(out.square[c].as_mut_ptr(),squares[c]);}
 out.sharpe=sharpe;
}
#[cfg(all(test,target_arch="x86_64",target_os="linux")))]
#[path="simd_tests.rs"]
mod tests;

#[cfg(not(all(target_arch="x86_64",target_os="linux")))]
pub fn batch(_pred:&[f64],_prices:&PriceStats,_jobs:&[Job],_assembly:bool)->Vec<BaseScore>{
 panic!("AVX-512 requires Linux x86-64; choose the compact or original stage")
}
