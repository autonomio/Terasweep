use super::*;
use crate::simd::{self, Job};
use std::io::Write;
use std::time::Instant;
#[derive(Clone, Copy)]
struct Bounds {
    lo: f64,
    hi: f64,
    alo: f64,
    ahi: f64,
}
impl Bounds {
    fn of(preds: &[f64]) -> Option<Self> {
        if preds.is_empty() || preds.iter().any(|p| !p.is_finite()) {
            return None;
        }
        let mut v = Self {
            lo: f64::INFINITY,
            hi: f64::NEG_INFINITY,
            alo: f64::INFINITY,
            ahi: 0.0,
        };
        for &p in preds {
            v.lo = v.lo.min(p);
            v.hi = v.hi.max(p);
            v.alo = v.alo.min(p.abs());
            v.ahi = v.ahi.max(p.abs());
        }
        Some(v)
    }
    fn constant(self, c: ScoreConfig) -> Option<bool> {
        let t = c.threshold;
        let (off, on) = match c.signal_rule.index() {
            0 => (self.hi <= t, self.lo > t),
            1 => (self.hi < t, self.lo >= t),
            2 => (self.lo >= t, self.hi < t),
            3 => (self.lo > t, self.hi <= t),
            4 => (self.ahi <= t, self.alo > t),
            5 => (self.ahi < t, self.alo >= t),
            _ => unreachable!(),
        };
        if off {
            Some(false)
        } else if on {
            Some(true)
        } else {
            None
        }
    }
}
fn key(idx: usize, c: ScoreConfig) -> ScoreKey {
    ScoreKey {
        train_idx: idx,
        threshold_bits: c.threshold.to_bits(),
        rule_idx: c.signal_rule.index(),
    }
}
fn constant_base(
    value: bool,
    cached: &mut [Option<BaseScore>; 2],
    pred: &[f64],
    c: ScoreConfig,
    p: &PriceStats,
) -> BaseScore {
    *cached[value as usize]
        .get_or_insert_with(|| results::compute_base_score(pred, c.threshold, c.signal_rule, p))
}
fn record(
    id: usize,
    c: ScoreConfig,
    e: &FitOut,
    base: Option<&BaseScore>,
    prices: &PriceStats,
) -> ScoredRow {
    let score = if e.fit_failed {
        (f64::NAN, f64::NAN, f64::NAN)
    } else if let Some(b) = base {
        results::apply_costs(b, e.preds.len(), c)
    } else {
        let b = results::compute_base_score(&e.preds, c.threshold, c.signal_rule, prices);
        results::apply_costs(&b, e.preds.len(), c)
    };
    ScoredRow {
        id,
        signal_rule: c.signal_rule,
        fit_failed: e.fit_failed,
        mae: results::round_to(e.mae, MAE_DECIMALS),
        signal_rate: score.0,
        net_return: score.1,
        sharpe: score.2,
    }
}
pub(super) fn run(
    stage: &str,
    config_json: &str,
    train: &Matrix,
    test: &Matrix,
    prices: &PriceStats,
    runs: usize,
) -> Result<RunOutput, Box<dyn std::error::Error>> {
    if ![
        "independent",
        "stats",
        "fits",
        "bounds",
        "compact",
        "intrinsics",
        "assembly",
        "export",
    ]
    .contains(&stage)
    {
        return Err(format!("unknown TERASWEEP_STAGE: {stage}").into());
    }
    if (stage == "intrinsics" || stage == "assembly") && !simd::available(stage == "assembly") {
        return Err(format!("{stage} requires Linux x86-64 AVX-512F; assembly also BMI1").into());
    }
    let total = Instant::now();
    let common = CommonSpace::from_json(config_json)?;
    let model = ModelSpace::from_json(config_json)?;
    let stats = precompute_stats(train);
    let train_cache = precompute_train_cache(&stats, test, &model.train_configs())?;
    let index: HashMap<TrainKey, usize> = train_cache
        .iter()
        .enumerate()
        .map(|(i, e)| (cache_key(e.config), i))
        .collect();
    let prep_seconds = total.elapsed().as_secs_f64();
    let bounds: Vec<Option<Bounds>> = train_cache.iter().map(|e| Bounds::of(&e.preds)).collect();
    let mut constants = [None, None];
    let mut summary = SweepSummary::new();
    let validate = std::env::var_os("TERASWEEP_VALIDATE").is_some();
    let mut checked = 0usize;
    let mut n_const = [0usize; 2];
    let mut phase_plan = 0.0;
    let mut phase_score = 0.0;
    let phase_reduce;
    let mut batches = 0;
    let entries;
    if stage == "export" {
        let path = std::env::var("TERASWEEP_EXPORT")?;
        let mut out = std::io::BufWriter::new(std::fs::File::create(path)?);
        writeln!(out,"id,alpha,fit_intercept,solver_eps,rule,threshold,fee_bps,slippage_bps,train_idx,fit_failed")?;
        for id in 0..runs {
            let p = model.sample(&common, id);
            let idx = index[&cache_key(p.train)];
            writeln!(
                out,
                "{},{:.17e},{},{:.17e},{},{:.17e},{:.17e},{:.17e},{},{}",
                id,
                p.train.alpha,
                p.train.fit_intercept,
                p.train.solver_eps,
                p.score.signal_rule.index(),
                p.score.threshold,
                p.score.fee_bps,
                p.score.slippage_bps,
                idx,
                train_cache[idx].fit_failed
            )?;
        }
        out.flush()?;
        return super::run_original(config_json, train, test, prices, runs);
    }
    if ["compact", "intrinsics", "assembly"].contains(&stage) {
        // Keep categorical keys identical to the original float-bit identities.
        let train_slots: Vec<usize> = model
            .train_configs()
            .iter()
            .map(|c| index[&cache_key(*c)])
            .collect();
        let mut th_index = HashMap::new();
        let mut th_next = 0usize;
        let mut th_ord = |values: &[f64]| -> Vec<usize> {
            values
                .iter()
                .map(|x| {
                    *th_index.entry(x.to_bits()).or_insert_with(|| {
                        let i = th_next;
                        th_next += 1;
                        i
                    })
                })
                .collect()
        };
        let signed = th_ord(&common.threshold_signed);
        let absolute = th_ord(&common.threshold_abs);
        let stride = 6usize.checked_mul(th_next).ok_or("score stride overflow")?;
        let capacity = train_cache
            .len()
            .checked_mul(stride)
            .ok_or("score index overflow")?;
        if capacity > 134_217_728 {
            return Err("compact score index exceeds 512 MiB; reduce score domain".into());
        }
        let mut slots = vec![0u32; capacity];
        let mut jobs = Vec::<Job>::new();
        let plan_start = Instant::now();
        let sample = |id: usize| -> (usize, ScoreConfig, usize) {
            let mut rng = SplitMix64::new(common.seed ^ results::mix_id(id as u64));
            let rule = common.signal_rules[rng.index(common.signal_rules.len())];
            let (thresholds, ord) = if rule.is_abs() {
                (&common.threshold_abs, &absolute)
            } else {
                (&common.threshold_signed, &signed)
            };
            let ai = rng.index(model.alphas.len());
            let ti = rng.index(thresholds.len());
            let fi = rng.index(model.fit_intercepts.len());
            let ei = rng.index(model.solver_eps.len());
            let fee = common.fee_bps[rng.index(common.fee_bps.len())];
            let slip = common.slippage_bps[rng.index(common.slippage_bps.len())];
            let idx =
                train_slots[(ai * model.fit_intercepts.len() + fi) * model.solver_eps.len() + ei];
            let c = ScoreConfig {
                threshold: thresholds[ti],
                signal_rule: rule,
                fee_bps: fee,
                slippage_bps: slip,
            };
            (idx, c, idx * stride + rule.index() * th_next + ord[ti])
        };
        let mut unique = 0;
        for id in 0..runs {
            let (idx, c, slot) = sample(id);
            let e = &train_cache[idx];
            if e.fit_failed || slots[slot] != 0 {
                continue;
            }
            unique += 1;
            if let Some(value) = bounds[idx].and_then(|b| b.constant(c)) {
                let b = constant_base(value, &mut constants, &e.preds, c, prices);
                slots[slot] = if value { 2 } else { 1 };
                n_const[value as usize] += 1;
                if validate {
                    let expected =
                        results::compute_base_score(&e.preds, c.threshold, c.signal_rule, prices);
                    assert!(b.bitwise_eq(&expected), "constant score differs at {id}");
                    checked += 1;
                }
            } else {
                if jobs.len() > u32::MAX as usize - 3 {
                    return Err("too many mixed jobs".into());
                }
                slots[slot] = jobs.len() as u32 + 3;
                jobs.push(Job {
                    train: idx,
                    slot,
                    score: c,
                });
            }
        }
        phase_plan = plan_start.elapsed().as_secs_f64();
        let score_start = Instant::now();
        jobs.sort_unstable_by_key(|j| (j.train, j.slot));
        let mut scores = Vec::with_capacity(jobs.len());
        let mut k = 0;
        while k < jobs.len() {
            let mut end = k + 1;
            while end < jobs.len() && end - k < 8 && jobs[end].train == jobs[k].train {
                end += 1;
            }
            let group = &jobs[k..end];
            let pred = &train_cache[group[0].train].preds;
            let batch: Vec<BaseScore> = if stage == "compact" {
                group
                    .iter()
                    .map(|j| {
                        results::compute_base_score(
                            pred,
                            j.score.threshold,
                            j.score.signal_rule,
                            prices,
                        )
                    })
                    .collect()
            } else {
                simd::batch(pred, prices, group, stage == "assembly")
            };
            for (j, b) in group.iter().zip(batch) {
                if validate {
                    let expected = results::compute_base_score(
                        pred,
                        j.score.threshold,
                        j.score.signal_rule,
                        prices,
                    );
                    assert!(
                        b.bitwise_eq(&expected),
                        "SIMD differs: train {}, slot {}",
                        j.train,
                        j.slot
                    );
                    checked += 1;
                }
                slots[j.slot] = scores.len() as u32 + 3;
                scores.push(b);
            }
            batches += 1;
            k = end;
        }
        phase_score = score_start.elapsed().as_secs_f64();
        let reduce_start = Instant::now();
        for id in 0..runs {
            let (idx, c, slot) = sample(id);
            let e = &train_cache[idx];
            let base = if e.fit_failed {
                None
            } else {
                match slots[slot] {
                    1 => constants[0].as_ref(),
                    2 => constants[1].as_ref(),
                    v if v >= 3 => Some(&scores[(v - 3) as usize]),
                    _ => panic!("missing planned score"),
                }
            };
            summary.record(record(id, c, e, base, prices));
        }
        entries = unique;
        phase_reduce = reduce_start.elapsed().as_secs_f64();
    } else {
        let mut cache = HashMap::<ScoreKey, BaseScore>::new();
        let loop_start = Instant::now();
        for id in 0..runs {
            let param = model.sample(&common, id);
            let idx = index[&cache_key(param.train)];
            let saved = &train_cache[idx];
            let computed;
            let e = if stage == "independent" || stage == "stats" {
                let local_stats;
                let st = if stage == "independent" {
                    local_stats = precompute_stats(train);
                    &local_stats
                } else {
                    &stats
                };
                computed = match fit_from_stats(st, param.train) {
                    Ok(beta) => {
                        let (preds, mae) = predict_and_mae(test, &beta);
                        FitOut {
                            config: param.train,
                            preds,
                            mae,
                            fit_failed: false,
                        }
                    }
                    Err(_) => FitOut {
                        config: param.train,
                        preds: Vec::new(),
                        mae: f64::NAN,
                        fit_failed: true,
                    },
                };
                &computed
            } else {
                saved
            };
            let base = if e.fit_failed {
                None
            } else {
                let sk = key(idx, param.score);
                let b = if stage == "bounds" {
                    if let Some(b) = cache.get(&sk) {
                        *b
                    } else if let Some(value) = bounds[idx].and_then(|v| v.constant(param.score)) {
                        n_const[value as usize] += 1;
                        let b = constant_base(value, &mut constants, &e.preds, param.score, prices);
                        if validate {
                            let expected = results::compute_base_score(
                                &e.preds,
                                param.score.threshold,
                                param.score.signal_rule,
                                prices,
                            );
                            assert!(b.bitwise_eq(&expected));
                            checked += 1;
                        }
                        b
                    } else {
                        results::compute_base_score(
                            &e.preds,
                            param.score.threshold,
                            param.score.signal_rule,
                            prices,
                        )
                    }
                } else {
                    results::compute_base_score(
                        &e.preds,
                        param.score.threshold,
                        param.score.signal_rule,
                        prices,
                    )
                };
                cache.insert(sk, b);
                Some(b)
            };
            summary.record(record(id, param.score, e, base.as_ref(), prices));
        }
        entries = cache.len();
        phase_reduce = loop_start.elapsed().as_secs_f64();
    }
    let best_return_json = row_json(
        summary.best_return(),
        &model,
        &common,
        &index,
        &train_cache,
        prices,
    );
    let best_sharpe_json = row_json(
        summary.best_sharpe(),
        &model,
        &common,
        &index,
        &train_cache,
        prices,
    );
    let best_mae_json = row_json(
        summary.best_mae(),
        &model,
        &common,
        &index,
        &train_cache,
        prices,
    );
    eprintln!("STAGES {{\"stage\":\"{}\",\"prep_seconds\":{:.9},\"plan_seconds\":{:.9},\"score_seconds\":{:.9},\"reduce_seconds\":{:.9},\"constant_off_keys\":{},\"constant_on_keys\":{},\"logical_score_keys\":{},\"batches\":{},\"validated_scores\":{}}}",stage,prep_seconds,phase_plan,phase_score,phase_reduce,n_const[0],n_const[1],entries,batches,checked);
    Ok(RunOutput {
        unique_alphas: model.alphas.len(),
        unique_train_configs: train_cache.len(),
        failed_train_configs: train_cache.iter().filter(|e| e.fit_failed).count(),
        score_cache_entries: entries,
        best_return_json,
        best_sharpe_json,
        best_mae_json,
        summary,
    })
}
