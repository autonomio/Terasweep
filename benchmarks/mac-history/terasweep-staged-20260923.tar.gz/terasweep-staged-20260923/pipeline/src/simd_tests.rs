use super::*;
use crate::results::{self, SignalRule};
use crate::ridge::{precompute_stats, precompute_train_cache, TrainConfig};

#[test]
fn packed_assembly_abi() {
    assert_eq!(std::mem::offset_of!(KernelPrices, cont), 24);
    assert_eq!(std::mem::offset_of!(Packed8, inclusive), 192);
    assert_eq!(std::mem::offset_of!(Raw8, sharpe), 896);
    assert_eq!(std::mem::size_of::<Raw8>(), 904);
}

#[test]
#[ignore = "requires a native Linux x86-64 AVX-512F/BMI1 execution target"]
fn real_data_simd_wrapper_matches_scalar() {
    assert!(available(true), "AVX-512F and BMI1 are required");
    let train = crate::read_matrix(include_bytes!("../data/train.bin")).unwrap();
    let test = crate::read_matrix(include_bytes!("../data/test.bin")).unwrap();
    let prices = crate::read_prices(include_bytes!("../data/price.bin")).unwrap();
    let prices = results::precompute_price_stats(&prices);
    let mut configs = Vec::new();
    for alpha in [0.1, 1.0, 1000.0, 100000.0] {
        for fit_intercept in [true, false] {
            configs.push(TrainConfig {
                alpha,
                fit_intercept,
                solver_eps: 1e-12,
            });
        }
    }
    let fits = precompute_train_cache(&precompute_stats(&train), &test, &configs).unwrap();
    let rules = [
        SignalRule::Gt,
        SignalRule::Gte,
        SignalRule::Lt,
        SignalRule::Lte,
        SignalRule::AbsGt,
        SignalRule::AbsGte,
    ];
    let mut checked = 0usize;
    for fit in fits.iter().filter(|x| !x.fit_failed) {
        for n in [
            0,
            1,
            2,
            7,
            8,
            9,
            15,
            16,
            17,
            63,
            64,
            65,
            test.rows - 1,
            test.rows,
        ] {
            for gaps in 0..4 {
                let mut p = PriceStats {
                    tradable: prices.tradable[..n].to_vec(),
                    r_entry: prices.r_entry[..n].to_vec(),
                    r_cont: prices.r_cont[..n].to_vec(),
                };
                if gaps == 1 {
                    p.tradable.fill(false);
                }
                if gaps == 2 {
                    for i in (0..n).step_by(7) {
                        p.tradable[i] = false;
                    }
                }
                if gaps == 3 && n > 0 {
                    p.tradable[0] = false;
                    p.tradable[n - 1] = false;
                }
                let jobs: Vec<Job> = (0..8)
                    .map(|lane| {
                        let rule = rules[(lane + gaps) % 6];
                        let mut t = fit.preds[(lane * 127) % test.rows];
                        if rule.is_abs() {
                            t = t.abs();
                        }
                        if lane == 6 {
                            t = 0.0;
                        }
                        if lane == 7 {
                            t = -0.0;
                        }
                        Job {
                            train: 0,
                            slot: lane,
                            score: ScoreConfig {
                                threshold: t,
                                signal_rule: rule,
                                fee_bps: 0.0,
                                slippage_bps: 0.0,
                            },
                        }
                    })
                    .collect();
                for used in 1..=8 {
                    for assembly in [false, true] {
                        let actual = batch(&fit.preds[..n], &p, &jobs[..used], assembly);
                        assert_eq!(actual.len(), used);
                        for (a, j) in actual.iter().zip(&jobs[..used]) {
                            let expected = results::compute_base_score(
                                &fit.preds[..n],
                                j.score.threshold,
                                j.score.signal_rule,
                                &p,
                            );
                            assert!(
                                a.bitwise_eq(&expected),
                                "mismatch n={n}, gaps={gaps}, used={used}, assembly={assembly}"
                            );
                            checked += 1;
                        }
                    }
                }
            }
        }
    }
    assert!(checked > 0);
    eprintln!("Rust SIMD wrapper validation checked {checked} complete BaseScores");
}
