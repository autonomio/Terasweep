"""Native, unmodified Limen Ridge SFD on the exact prepared matrices and sampled calls."""
import argparse,csv,json,struct,time,warnings,hashlib
from pathlib import Path
import numpy as np
import polars as pl
from limen.sfd.reference_architecture import ridge_regressor
import importlib.metadata as metadata

def matrix(path):
 b=path.read_bytes();assert b[:8]==b'RIDGE001';n,d=struct.unpack_from('<QQ',b,8)
 v=np.frombuffer(b,offset=24,dtype='<f8');assert v.size==n*d+n
 return v[:n*d].reshape(n,d).copy(),v[n*d:].copy()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--trials',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--limit',type=int)
 a=ap.parse_args();x,y=matrix(a.root/'data/train.bin');xt,yt=matrix(a.root/'data/test.bin')
 b=(a.root/'data/price.bin').read_bytes();assert b[:8]==b'PRICE001';n=struct.unpack_from('<Q',b,8)[0];v=np.frombuffer(b,offset=16,dtype='<f8')
 data={'x_train':x,'y_train':y,'x_test':xt,'y_test':yt,'price_data_for_backtest':pl.DataFrame({'open':v[:n],'close':v[n:]})}
 with a.trials.open() as f:trials=list(csv.DictReader(f))
 if a.limit is not None:trials=trials[:a.limit]
 assert all(t['rule']=='0' and float(t['threshold'])==0 and t['fit_failed']=='false' for t in trials)
 # Only the common native signal contract is admitted; solver_eps is NOT mapped to sklearn tol.
 first={};warnings_count=0;mae_sum=0.;start=time.perf_counter()
 for i,t in enumerate(trials):
  data['backtest_fee_bps']=float(t['fee_bps']);data['backtest_slip_bps']=float(t['slippage_bps'])
  with warnings.catch_warnings(record=True) as w:
   warnings.simplefilter('always')
   result=ridge_regressor(data,alpha=float(t['alpha']),fit_intercept=t['fit_intercept']=='true',solver='cholesky')
  warnings_count+=len(w);mae_sum+=float(result['mae'])
  idx=t['train_idx']
  if idx not in first:
   p=np.asarray(result['_preds']);assert np.isfinite(p).all()
   first[idx]={'alpha':float(t['alpha']),'fit_intercept':t['fit_intercept']=='true','mae':float(result['mae']),'signal_count':int((p>0).sum()),'prediction_sha256':hashlib.sha256(p.tobytes()).hexdigest()}
 elapsed=time.perf_counter()-start
 out={'rows':len(trials),'call_loop_seconds':elapsed,'seconds_per_call':elapsed/len(trials),'warnings':warnings_count,'mae_sum':mae_sum,'models':first,'versions':{p:metadata.version(p) for p in ['vaquum-limen','numpy','scikit-learn','scipy','polars']},'boundary':'native ridge_regressor calls, including fit, predict, all native regression/confusion/backtest metrics; excludes imports, input loading and final JSON','economics':'native Limen backtest; not asserted identical to historical Terasweep'}
 a.out.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
