import json,os,statistics,subprocess,time
from pathlib import Path
r=Path('/Users/mikkokotila/dev/_reports/terasweep-staged-20260923');p=r/'pipeline';out=r/'arm-bench'
exe=p/'target/terasweep';rows=[]
def stable(v):return {k:x for k,x in v.items() if k not in {'hot_loop_seconds','hot_loop_iterations_per_second'}}
def run(stage,count,config,label,repeat):
 d=out/f'{label}-{stage}-{repeat}';d.mkdir(parents=True,exist_ok=False)
 env=os.environ.copy();env['TERASWEEP_STAGE']=stage;env.pop('TERASWEEP_VALIDATE',None)
 cmd=[str(exe),str(p/'data/train.bin'),str(p/'data/test.bin'),str(p/'data/price.bin'),str(config),str(count),str(d/'summary.json')]
 start=time.perf_counter()
 with (d/'stdout.txt').open('w') as so,(d/'time.txt').open('w') as se:
  subprocess.run(['/usr/bin/time','-lp',*cmd],check=True,env=env,stdout=so,stderr=se)
 wall=time.perf_counter()-start;summary=json.loads((d/'summary.json').read_text())
 expected=json.loads((r/'common/original.json' if label=='common' else p/'golden/1m.json').read_text())
 assert stable(summary)==stable(expected),(stage,label)
 timing=(d/'time.txt').read_text();rss=None;phases=None
 for line in timing.splitlines():
  if 'maximum resident set size' in line:rss=int(line.split()[0])
  if line.startswith('STAGES '):phases=json.loads(line[7:])
 row={'stage':stage,'rows':count,'workload':label,'repeat':repeat,'wall_seconds':wall,'internal_seconds':summary['hot_loop_seconds'],'max_rss_bytes':rss,'phases':phases,'golden_pass':True}
 rows.append(row);(out/'timings.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
# One controlled slow ablation, not a repeated long benchmark.
run('independent',10000,r/'common/config.json','common',0)
stages=['stats','fits','original','bounds','compact']
for repeat in range(5):
 for stage in stages[repeat:]+stages[:repeat]:run(stage,10000,r/'common/config.json','common',repeat+1)
for repeat in range(3):
 order=['fits','original','bounds','compact'];order=order[repeat:]+order[:repeat]
 for stage in order:run(stage,1000000,p/'configs/sweep.json','canonical',repeat+1)
summary={}
for label in ['common','canonical']:
 summary[label]={}
 for stage in ['independent',*stages]:
  a=[x for x in rows if x['workload']==label and x['stage']==stage]
  if a:summary[label][stage]={'n':len(a),'median_wall_seconds':statistics.median(x['wall_seconds'] for x in a),'median_internal_seconds':statistics.median(x['internal_seconds'] for x in a),'median_max_rss_bytes':statistics.median(x['max_rss_bytes'] for x in a),'range_wall_seconds':[min(x['wall_seconds'] for x in a),max(x['wall_seconds'] for x in a)]}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
