
/Users/mikkokotila/dev/Terasweep/target/terasweep:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010000d114 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E>:
10000d114:     	stp	d13, d12, [sp, #-0x90]!
10000d118:     	stp	d11, d10, [sp, #0x10]
10000d11c:     	stp	d9, d8, [sp, #0x20]
10000d120:     	stp	x28, x27, [sp, #0x30]
10000d124:     	stp	x26, x25, [sp, #0x40]
10000d128:     	stp	x24, x23, [sp, #0x50]
10000d12c:     	stp	x22, x21, [sp, #0x60]
10000d130:     	stp	x20, x19, [sp, #0x70]
10000d134:     	stp	x29, x30, [sp, #0x80]
10000d138:     	add	x29, sp, #0x80
10000d13c:     	mov	x24, x6
10000d140:     	mov	x22, x5
10000d144:     	mov	x21, x4
10000d148:     	mov	x20, x3
10000d14c:     	mov	x23, x2
10000d150:     	stp	x0, x1, [sp, #-0x170]!
10000d154:     	add	x26, sp, #0xc0
10000d158:     	ldr	d8, [x4]
10000d15c:     	ldrb	w28, [x4, #0x18]
10000d160:     	eor	w8, w28, #0x4
10000d164:     	adrp	x9, 0x100052000 <_write+0x100052000>
10000d168:     	add	x9, x9, #0x268
10000d16c:     	ldr	x19, [x9, w8, uxtw #3]
10000d170:     	str	d8, [sp, #0x10]
10000d174:     	str	x19, [sp, #0x18]
10000d178:     	ldr	x8, [x5, #0x28]
10000d17c:     	cbz	x8, 0x10000d24c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x138>
10000d180:     	mov	x25, x1
10000d184:     	fmov	x27, d8
10000d188:     	ldp	x0, x1, [x22]
10000d18c:     	add	x2, sp, #0x8
10000d190:     	bl	0x100002f74 <__ZN4core4hash11BuildHasher8hash_one17h0ac68ddfb3e08a33E>
10000d194:     	mov	x1, #-0x101010101010102 ; =-72340172838076674
10000d198:     	movk	x1, #0xfeff
10000d19c:     	mov	x8, #0x0                ; =0
10000d1a0:     	lsr	x12, x0, #57
10000d1a4:     	ldp	x9, x10, [x22, #0x10]
10000d1a8:     	and	x11, x9, x0
10000d1ac:     	mov	x13, #0x101010101010101 ; =72340172838076673
10000d1b0:     	mul	x12, x12, x13
10000d1b4:     	mov	w13, #0x98              ; =152
10000d1b8:     	ldr	x14, [x10, x11]
10000d1bc:     	eor	x15, x14, x12
10000d1c0:     	add	x16, x15, x1
10000d1c4:     	bic	x15, x16, x15
10000d1c8:     	ands	x15, x15, #0x8080808080808080
10000d1cc:     	b.ne	0x10000d1f8 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0xe4>
10000d1d0:     	and	x14, x14, x14, lsl #1
10000d1d4:     	tst	x14, #0x8080808080808080
10000d1d8:     	b.ne	0x10000d24c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x138>
10000d1dc:     	add	x8, x8, #0x8
10000d1e0:     	add	x11, x11, x8
10000d1e4:     	and	x11, x11, x9
10000d1e8:     	b	0x10000d1b8 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0xa4>
10000d1ec:     	sub	x16, x15, #0x1
10000d1f0:     	and	x15, x16, x15
10000d1f4:     	cbz	x15, 0x10000d1d0 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0xbc>
10000d1f8:     	rbit	x16, x15
10000d1fc:     	clz	x16, x16
10000d200:     	add	x16, x11, x16, lsr #3
10000d204:     	and	x16, x16, x9
10000d208:     	mneg	x16, x16, x13
10000d20c:     	add	x16, x10, x16
10000d210:     	ldp	x17, x0, [x16, #-0x98]
10000d214:     	cmp	x17, x25
10000d218:     	ccmp	x0, x27, #0x0, eq
10000d21c:     	b.ne	0x10000d1ec <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0xd8>
10000d220:     	ldur	x17, [x16, #-0x88]
10000d224:     	cmp	x19, x17
10000d228:     	b.ne	0x10000d1ec <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0xd8>
10000d22c:     	ldp	q0, q1, [x16, #-0x40]
10000d230:     	stp	q0, q1, [x26, #0x40]
10000d234:     	ldp	q0, q1, [x16, #-0x20]
10000d238:     	stp	q0, q1, [x26, #0x60]
10000d23c:     	ldp	q0, q1, [x16, #-0x80]
10000d240:     	stp	q0, q1, [x26]
10000d244:     	ldp	q0, q1, [x16, #-0x60]
10000d248:     	b	0x10000d62c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x518>
10000d24c:     	movi.16b	v0, #0x0
10000d250:     	stur	q0, [sp, #0x38]
10000d254:     	add	x25, sp, #0x20
10000d258:     	stur	q0, [sp, #0x48]
10000d25c:     	stur	q0, [sp, #0x58]
10000d260:     	stur	q0, [sp, #0x68]
10000d264:     	stur	q0, [sp, #0x78]
10000d268:     	stur	q0, [x25, #0x68]
10000d26c:     	mov	x8, #0x3ff0000000000000 ; =4607182418800017408
10000d270:     	stp	xzr, x8, [sp, #0x20]
10000d274:     	str	xzr, [sp, #0x98]
10000d278:     	str	xzr, [sp, #0x30]
10000d27c:     	cbz	x20, 0x10000d508 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x3f4>
10000d280:     	mov	x8, #0x0                ; =0
10000d284:     	lsl	x9, x20, #3
10000d288:     	and	x10, x28, #0x7
10000d28c:     	mov	x11, x23
10000d290:     	adrp	x12, 0x100051000 <_write+0x100051000>
10000d294:     	add	x12, x12, #0xc9
10000d298:     	b	0x10000d2a8 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x194>
10000d29c:     	add	x8, x8, #0x1
10000d2a0:     	subs	x9, x9, #0x8
10000d2a4:     	b.eq	0x10000d2f4 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x1e0>
10000d2a8:     	ldr	d0, [x11], #0x8
10000d2ac:     	adr	x13, 0x10000d2bc <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x1a8>
10000d2b0:     	ldrb	w14, [x12, x10]
10000d2b4:     	add	x13, x13, x14, lsl #2
10000d2b8:     	br	x13
10000d2bc:     	fcmp	d0, d8
10000d2c0:     	b.mi	0x10000d29c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x188>
10000d2c4:     	b	0x10000d2a0 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x18c>
10000d2c8:     	fcmp	d0, d8
10000d2cc:     	b.ls	0x10000d29c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x188>
10000d2d0:     	b	0x10000d2a0 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x18c>
10000d2d4:     	fabs	d0, d0
10000d2d8:     	fcmp	d0, d8
10000d2dc:     	b.gt	0x10000d29c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x188>
10000d2e0:     	b	0x10000d2a0 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x18c>
10000d2e4:     	fabs	d0, d0
10000d2e8:     	fcmp	d0, d8
10000d2ec:     	b.ge	0x10000d29c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x188>
10000d2f0:     	b	0x10000d2a0 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x18c>
10000d2f4:     	mov	x11, #0x0               ; =0
10000d2f8:     	mov	w12, #0x0               ; =0
10000d2fc:     	mov	w13, #0x0               ; =0
10000d300:     	mov	w10, #0x0               ; =0
10000d304:     	mov	x0, #0x0                ; =0
10000d308:     	mov	w14, #0x0               ; =0
10000d30c:     	str	x8, [sp, #0x20]
10000d310:     	ldr	x9, [x24]
10000d314:     	ldp	x1, x15, [x24, #0x10]
10000d318:     	ldr	x8, [x24, #0x40]
10000d31c:     	add	x16, x9, #0x1
10000d320:     	mov	x9, x28
10000d324:     	and	x17, x9, #0x7
10000d328:     	ldp	x9, x2, [x24, #0x28]
10000d32c:     	fmov	d0, #1.00000000
10000d330:     	adrp	x3, 0x100051000 <_write+0x100051000>
10000d334:     	add	x3, x3, #0xd5
10000d338:     	fmov	d1, xzr
10000d33c:     	mov	w4, #0x2                ; =2
10000d340:     	add	x5, sp, #0x20
10000d344:     	and	x6, x28, #0x7
10000d348:     	adrp	x7, 0x100051000 <_write+0x100051000>
10000d34c:     	add	x7, x7, #0xcf
10000d350:     	fmov	d2, #1.00000000
10000d354:     	b	0x10000d36c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x258>
10000d358:     	fmul	d2, d2, d3
10000d35c:     	add	x23, x23, #0x8
10000d360:     	mov	x0, x24
10000d364:     	cmp	x20, x24
10000d368:     	b.eq	0x10000d4fc <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x3e8>
10000d36c:     	mov	x28, x10
10000d370:     	cbz	x0, 0x10000d3b4 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x2a0>
10000d374:     	cmp	x1, x0
10000d378:     	b.ls	0x10000d964 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x850>
10000d37c:     	add	x10, x16, x0
10000d380:     	ldurb	w10, [x10, #-0x1]
10000d384:     	cbz	w10, 0x10000d3e4 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x2d0>
10000d388:     	sub	x10, x0, #0x1
10000d38c:     	cmp	x10, x20
10000d390:     	b.hs	0x10000da18 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x904>
10000d394:     	ldur	d3, [x23, #-0x8]
10000d398:     	adr	x10, 0x10000d3a8 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x294>
10000d39c:     	ldrb	w19, [x7, x6]
10000d3a0:     	add	x10, x10, x19, lsl #2
10000d3a4:     	br	x10
10000d3a8:     	fcmp	d3, d8
10000d3ac:     	cset	w10, mi
10000d3b0:     	b	0x10000d3e4 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x2d0>
10000d3b4:     	mov	w10, #0x0               ; =0
10000d3b8:     	b	0x10000d3e4 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x2d0>
10000d3bc:     	fcmp	d3, d8
10000d3c0:     	cset	w10, ls
10000d3c4:     	b	0x10000d3e4 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x2d0>
10000d3c8:     	fabs	d3, d3
10000d3cc:     	fcmp	d3, d8
10000d3d0:     	cset	w10, gt
10000d3d4:     	b	0x10000d3e4 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x2d0>
10000d3d8:     	fabs	d3, d3
10000d3dc:     	fcmp	d3, d8
10000d3e0:     	cset	w10, ge
10000d3e4:     	add	x24, x0, #0x1
10000d3e8:     	cmp	x24, x20
10000d3ec:     	b.hs	0x10000d420 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x30c>
10000d3f0:     	cmp	x1, x24
10000d3f4:     	b.ls	0x10000d9e8 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x8d4>
10000d3f8:     	ldrb	w19, [x16, x0]
10000d3fc:     	cbz	w19, 0x10000d424 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x310>
10000d400:     	ldr	d3, [x23]
10000d404:     	adr	x19, 0x10000d414 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x300>
10000d408:     	ldrb	w27, [x3, x17]
10000d40c:     	add	x19, x19, x27, lsl #2
10000d410:     	br	x19
10000d414:     	fcmp	d3, d8
10000d418:     	cset	w19, mi
10000d41c:     	b	0x10000d424 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x310>
10000d420:     	mov	w19, #0x0               ; =0
10000d424:     	eor	w27, w28, #0x1
10000d428:     	and	w27, w10, w27
10000d42c:     	fmov	d3, xzr
10000d430:     	tbz	w27, #0x0, 0x10000d448 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x334>
10000d434:     	cmp	x9, x0
10000d438:     	b.ls	0x10000d9f8 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x8e4>
10000d43c:     	ldr	d3, [x15, x0, lsl #3]
10000d440:     	fadd	d3, d3, d1
10000d444:     	add	w13, w13, #0x1
10000d448:     	and	w28, w28, w10
10000d44c:     	tbz	w28, #0x0, 0x10000d460 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x34c>
10000d450:     	cmp	x8, x0
10000d454:     	b.ls	0x10000da08 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x8f4>
10000d458:     	ldr	d4, [x2, x0, lsl #3]
10000d45c:     	fadd	d3, d3, d4
10000d460:     	eor	w19, w19, #0x1
10000d464:     	and	w19, w10, w19
10000d468:     	cmp	w19, #0x0
10000d46c:     	csinc	w12, w12, w14, eq
10000d470:     	cinc	w14, w14, ne
10000d474:     	fadd	d3, d3, d0
10000d478:     	cbz	x0, 0x10000d358 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x244>
10000d47c:     	cmp	x1, x0
10000d480:     	b.ls	0x10000d970 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x85c>
10000d484:     	add	x0, x16, x0
10000d488:     	ldurb	w0, [x0, #-0x1]
10000d48c:     	cbz	w0, 0x10000d358 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x244>
10000d490:     	cmp	w19, #0x0
10000d494:     	csel	x0, x4, xzr, ne
10000d498:     	orr	x0, x0, x27
10000d49c:     	add	x11, x11, #0x1
10000d4a0:     	add	x0, x5, x0, lsl #3
10000d4a4:     	ldr	x19, [x0, #0x18]
10000d4a8:     	add	x19, x19, #0x1
10000d4ac:     	str	x19, [x0, #0x18]
10000d4b0:     	ldr	d4, [x0, #0x38]
10000d4b4:     	fadd	d4, d3, d4
10000d4b8:     	str	d4, [x0, #0x38]
10000d4bc:     	fmul	d4, d3, d3
10000d4c0:     	ldr	d5, [x0, #0x58]
10000d4c4:     	fadd	d4, d4, d5
10000d4c8:     	str	d4, [x0, #0x58]
10000d4cc:     	b	0x10000d358 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x244>
10000d4d0:     	fcmp	d3, d8
10000d4d4:     	cset	w19, ls
10000d4d8:     	b	0x10000d424 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x310>
10000d4dc:     	fabs	d3, d3
10000d4e0:     	fcmp	d3, d8
10000d4e4:     	cset	w19, gt
10000d4e8:     	b	0x10000d424 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x310>
10000d4ec:     	fabs	d3, d3
10000d4f0:     	fcmp	d3, d8
10000d4f4:     	cset	w19, ge
10000d4f8:     	b	0x10000d424 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x310>
10000d4fc:     	stp	w13, w12, [sp, #0x98]
10000d500:     	str	d2, [sp, #0x28]
10000d504:     	str	x11, [sp, #0x30]
10000d508:     	ldur	q0, [sp, #0x8]
10000d50c:     	str	q0, [x25, #0x80]
10000d510:     	ldr	x8, [sp, #0x18]
10000d514:     	str	x8, [sp, #0xb0]
10000d518:     	ldp	x0, x1, [x22]
10000d51c:     	add	x2, sp, #0xa0
10000d520:     	bl	0x100002f74 <__ZN4core4hash11BuildHasher8hash_one17h0ac68ddfb3e08a33E>
10000d524:     	mov	x5, #-0x101010101010102 ; =-72340172838076674
10000d528:     	movk	x5, #0xfeff
10000d52c:     	mov	x23, x0
10000d530:     	mov	x11, #0x0               ; =0
10000d534:     	lsr	x24, x0, #57
10000d538:     	ldp	x9, x8, [x22, #0x10]
10000d53c:     	and	x10, x9, x0
10000d540:     	mov	x12, #0x101010101010101 ; =72340172838076673
10000d544:     	mul	x12, x24, x12
10000d548:     	ldp	x13, x14, [sp, #0xa0]
10000d54c:     	ldr	x15, [sp, #0xb0]
10000d550:     	mov	w16, #0x98              ; =152
10000d554:     	mov	x17, x10
10000d558:     	ldr	x0, [x8, x17]
10000d55c:     	eor	x1, x0, x12
10000d560:     	add	x2, x1, x5
10000d564:     	bic	x1, x2, x1
10000d568:     	ands	x1, x1, #0x8080808080808080
10000d56c:     	b.ne	0x10000d598 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x484>
10000d570:     	and	x0, x0, x0, lsl #1
10000d574:     	tst	x0, #0x8080808080808080
10000d578:     	b.ne	0x10000d828 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x714>
10000d57c:     	add	x11, x11, #0x8
10000d580:     	add	x17, x17, x11
10000d584:     	and	x17, x17, x9
10000d588:     	b	0x10000d558 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x444>
10000d58c:     	sub	x2, x1, #0x1
10000d590:     	and	x1, x2, x1
10000d594:     	cbz	x1, 0x10000d570 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x45c>
10000d598:     	rbit	x2, x1
10000d59c:     	clz	x2, x2
10000d5a0:     	add	x2, x17, x2, lsr #3
10000d5a4:     	and	x2, x2, x9
10000d5a8:     	mneg	x2, x2, x16
10000d5ac:     	add	x2, x8, x2
10000d5b0:     	ldp	x3, x4, [x2, #-0x98]
10000d5b4:     	cmp	x13, x3
10000d5b8:     	ccmp	x14, x4, #0x0, eq
10000d5bc:     	b.ne	0x10000d58c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x478>
10000d5c0:     	ldur	x3, [x2, #-0x88]
10000d5c4:     	cmp	x15, x3
10000d5c8:     	b.ne	0x10000d58c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x478>
10000d5cc:     	ldr	q0, [sp, #0x60]
10000d5d0:     	stur	q0, [x2, #-0x40]
10000d5d4:     	ldr	q0, [sp, #0x70]
10000d5d8:     	stur	q0, [x2, #-0x30]
10000d5dc:     	ldr	q0, [sp, #0x80]
10000d5e0:     	stur	q0, [x2, #-0x20]
10000d5e4:     	ldr	q0, [x25, #0x70]
10000d5e8:     	stur	q0, [x2, #-0x10]
10000d5ec:     	ldr	q0, [sp, #0x20]
10000d5f0:     	stur	q0, [x2, #-0x80]
10000d5f4:     	ldr	q0, [sp, #0x30]
10000d5f8:     	stur	q0, [x2, #-0x70]
10000d5fc:     	ldr	q0, [sp, #0x40]
10000d600:     	stur	q0, [x2, #-0x60]
10000d604:     	ldr	q0, [sp, #0x50]
10000d608:     	stur	q0, [x2, #-0x50]
10000d60c:     	ldp	q0, q1, [sp, #0x60]
10000d610:     	stp	q0, q1, [x26, #0x40]
10000d614:     	ldr	q0, [sp, #0x80]
10000d618:     	ldr	q1, [x25, #0x70]
10000d61c:     	stp	q0, q1, [x26, #0x60]
10000d620:     	ldp	q0, q1, [sp, #0x20]
10000d624:     	stp	q0, q1, [x26]
10000d628:     	ldp	q0, q1, [sp, #0x40]
10000d62c:     	stp	q0, q1, [x26, #0x20]
10000d630:     	ldp	d0, d1, [x21, #0x8]
10000d634:     	mov	x8, #0x880000000000     ; =149533581377536
10000d638:     	movk	x8, #0x40c3, lsl #48
10000d63c:     	fmov	d2, x8
10000d640:     	fdiv	d0, d0, d2
10000d644:     	fdiv	d1, d1, d2
10000d648:     	fmov	d2, #1.00000000
10000d64c:     	fsub	d3, d2, d0
10000d650:     	fadd	d0, d1, d2
10000d654:     	fdiv	d0, d3, d0
10000d658:     	fsub	d1, d2, d1
10000d65c:     	fmul	d8, d3, d1
10000d660:     	fmul	d1, d0, d8
10000d664:     	mov	x8, #0x3ff0000000000000 ; =4607182418800017408
10000d668:     	str	x8, [sp, #0x20]
10000d66c:     	stp	d0, d8, [sp, #0x28]
10000d670:     	str	d1, [sp, #0x38]
10000d674:     	ldr	d9, [sp, #0xc8]
10000d678:     	ldr	w0, [sp, #0x138]
10000d67c:     	ldr	w21, [sp, #0x13c]
10000d680:     	ldr	x9, [sp, #0xc0]
10000d684:     	ldr	x10, [sp, #0xd0]
10000d688:     	cmp	x10, #0x2
10000d68c:     	b.lo	0x10000d784 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x670>
10000d690:     	mov	x16, #0x0               ; =0
10000d694:     	add	x11, sp, #0x20
10000d698:     	add	x12, x11, #0x20
10000d69c:     	fmov	d1, xzr
10000d6a0:     	mov	w13, #0x4               ; =4
10000d6a4:     	add	x14, sp, #0xc0
10000d6a8:     	fmov	d2, xzr
10000d6ac:     	mov	x15, #0x0               ; =0
10000d6b0:     	mov	x17, #0x0               ; =0
10000d6b4:     	cmp	x16, #0x4
10000d6b8:     	csel	x8, x16, x13, hi
10000d6bc:     	add	x1, x14, x16, lsl #3
10000d6c0:     	add	x2, x11, x17
10000d6c4:     	cmp	x2, x12
10000d6c8:     	b.eq	0x10000d734 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x620>
10000d6cc:     	cmp	x8, x15
10000d6d0:     	b.eq	0x10000d950 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x83c>
10000d6d4:     	add	x2, x1, x17
10000d6d8:     	ldr	x2, [x2, #0x18]
10000d6dc:     	add	x17, x17, #0x8
10000d6e0:     	add	x15, x15, #0x1
10000d6e4:     	cbz	x2, 0x10000d6c0 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x5ac>
10000d6e8:     	ucvtf	d3, x2
10000d6ec:     	add	x8, x14, x16, lsl #3
10000d6f0:     	add	x8, x8, x17
10000d6f4:     	ldr	d4, [x8, #0x30]
10000d6f8:     	add	x11, x11, x17
10000d6fc:     	ldur	d5, [x11, #-0x8]
10000d700:     	fmul	d6, d4, d5
10000d704:     	fsub	d6, d6, d3
10000d708:     	fadd	d2, d2, d6
10000d70c:     	fmul	d6, d5, d5
10000d710:     	ldr	d7, [x8, #0x50]
10000d714:     	fmul	d6, d6, d7
10000d718:     	fadd	d5, d5, d5
10000d71c:     	fmul	d4, d4, d5
10000d720:     	fsub	d4, d6, d4
10000d724:     	fadd	d3, d4, d3
10000d728:     	fadd	d1, d1, d3
10000d72c:     	mov	x16, x15
10000d730:     	b	0x10000d6b0 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x59c>
10000d734:     	ucvtf	d3, x10
10000d738:     	fdiv	d2, d2, d3
10000d73c:     	fmul	d4, d2, d3
10000d740:     	fmul	d4, d2, d4
10000d744:     	fsub	d1, d1, d4
10000d748:     	fmov	d4, #-1.00000000
10000d74c:     	fadd	d3, d3, d4
10000d750:     	fdiv	d1, d1, d3
10000d754:     	fmov	d3, xzr
10000d758:     	fmaxnm	d1, d1, d3
10000d75c:     	fsqrt	d1, d1
10000d760:     	fcmp	d1, #0.0
10000d764:     	b.le	0x10000d784 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x670>
10000d768:     	fdiv	d1, d2, d1
10000d76c:     	mov	x8, #0x4059000000000000 ; =4636737291354636288
10000d770:     	fmov	d2, x8
10000d774:     	fmul	d1, d1, d2
10000d778:     	frinta	d1, d1
10000d77c:     	fdiv	d10, d1, d2
10000d780:     	b	0x10000d78c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x678>
10000d784:     	mov	x8, #0x7ff8000000000000 ; =9221120237041090560
10000d788:     	fmov	d10, x8
10000d78c:     	ucvtf	d1, x9
10000d790:     	mov	x8, #0x4059000000000000 ; =4636737291354636288
10000d794:     	fmov	d11, x8
10000d798:     	fmul	d1, d1, d11
10000d79c:     	ucvtf	d2, x20
10000d7a0:     	fdiv	d1, d1, d2
10000d7a4:     	mov	x8, #0x400000000000     ; =70368744177664
10000d7a8:     	movk	x8, #0x408f, lsl #48
10000d7ac:     	fmov	d2, x8
10000d7b0:     	fmul	d1, d1, d2
10000d7b4:     	frinta	d1, d1
10000d7b8:     	fdiv	d12, d1, d2
10000d7bc:     	bl	0x10004b688 <___powidf2>
10000d7c0:     	fmul	d9, d9, d0
10000d7c4:     	fmov	d0, d8
10000d7c8:     	mov	x0, x21
10000d7cc:     	bl	0x10004b688 <___powidf2>
10000d7d0:     	fmul	d0, d9, d0
10000d7d4:     	fmov	d1, #-1.00000000
10000d7d8:     	fadd	d0, d0, d1
10000d7dc:     	fmul	d0, d0, d11
10000d7e0:     	fmov	d1, #10.00000000
10000d7e4:     	fmul	d0, d0, d1
10000d7e8:     	frinta	d0, d0
10000d7ec:     	fdiv	d0, d0, d1
10000d7f0:     	ldr	x8, [sp]
10000d7f4:     	stp	d12, d0, [x8]
10000d7f8:     	str	d10, [x8, #0x10]
10000d7fc:     	add	sp, sp, #0x170
10000d800:     	ldp	x29, x30, [sp, #0x80]
10000d804:     	ldp	x20, x19, [sp, #0x70]
10000d808:     	ldp	x22, x21, [sp, #0x60]
10000d80c:     	ldp	x24, x23, [sp, #0x50]
10000d810:     	ldp	x26, x25, [sp, #0x40]
10000d814:     	ldp	x28, x27, [sp, #0x30]
10000d818:     	ldp	d9, d8, [sp, #0x20]
10000d81c:     	ldp	d11, d10, [sp, #0x10]
10000d820:     	ldp	d13, d12, [sp], #0x90
10000d824:     	ret
10000d828:     	ldur	q0, [sp, #0x8]
10000d82c:     	str	q0, [x25, #0xa0]
10000d830:     	ldp	q0, q1, [sp, #0x60]
10000d834:     	stur	q0, [x25, #0xf8]
10000d838:     	stur	q1, [x26, #0x68]
10000d83c:     	ldr	q0, [sp, #0x80]
10000d840:     	stur	q0, [x26, #0x78]
10000d844:     	ldr	q0, [x25, #0x70]
10000d848:     	stur	q0, [x26, #0x88]
10000d84c:     	ldp	q0, q1, [sp, #0x20]
10000d850:     	stur	q0, [x26, #0x18]
10000d854:     	stur	q1, [x26, #0x28]
10000d858:     	ldp	q0, q1, [sp, #0x40]
10000d85c:     	stur	q0, [x26, #0x38]
10000d860:     	ldr	x11, [sp, #0x18]
10000d864:     	str	x11, [sp, #0xd0]
10000d868:     	stur	q1, [x26, #0x48]
10000d86c:     	ldr	x11, [x8, x10]
10000d870:     	ands	x11, x11, #0x8080808080808080
10000d874:     	b.ne	0x10000d894 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x780>
10000d878:     	mov	w12, #0x8               ; =8
10000d87c:     	add	x10, x10, x12
10000d880:     	and	x10, x10, x9
10000d884:     	ldr	x11, [x8, x10]
10000d888:     	add	x12, x12, #0x8
10000d88c:     	ands	x11, x11, #0x8080808080808080
10000d890:     	b.eq	0x10000d87c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x768>
10000d894:     	rbit	x11, x11
10000d898:     	clz	x11, x11
10000d89c:     	add	x10, x10, x11, lsr #3
10000d8a0:     	and	x10, x10, x9
10000d8a4:     	ldrsb	w11, [x8, x10]
10000d8a8:     	tbnz	w11, #0x1f, 0x10000d8c8 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x7b4>
10000d8ac:     	ldr	x10, [x8]
10000d8b0:     	and	x10, x10, #0x8080808080808080
10000d8b4:     	rbit	x10, x10
10000d8b8:     	clz	x10, x10
10000d8bc:     	lsr	x10, x10, #3
10000d8c0:     	ldrb	w11, [x8, x10]
10000d8c4:     	b	0x10000d8cc <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x7b8>
10000d8c8:     	and	w11, w11, #0xff
10000d8cc:     	ldr	x12, [x22, #0x20]
10000d8d0:     	and	w27, w11, #0x1
10000d8d4:     	cbnz	x12, 0x10000d8dc <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x7c8>
10000d8d8:     	cbnz	w27, 0x10000d97c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x868>
10000d8dc:     	strb	w24, [x8, x10]
10000d8e0:     	sub	x11, x10, #0x8
10000d8e4:     	and	x9, x11, x9
10000d8e8:     	add	x9, x9, x8
10000d8ec:     	strb	w24, [x9, #0x8]
10000d8f0:     	mov	w9, #0x98               ; =152
10000d8f4:     	mneg	x9, x10, x9
10000d8f8:     	add	x8, x8, x9
10000d8fc:     	ldp	q1, q0, [x26]
10000d900:     	stur	q0, [x8, #-0x88]
10000d904:     	stur	q1, [x8, #-0x98]
10000d908:     	ldp	q1, q0, [x26, #0x40]
10000d90c:     	stur	q0, [x8, #-0x48]
10000d910:     	stur	q1, [x8, #-0x58]
10000d914:     	ldp	q1, q0, [x26, #0x20]
10000d918:     	stur	q0, [x8, #-0x68]
10000d91c:     	stur	q1, [x8, #-0x78]
10000d920:     	ldr	q0, [x26, #0x80]
10000d924:     	stur	q0, [x8, #-0x18]
10000d928:     	ldp	q1, q0, [x26, #0x60]
10000d92c:     	stur	q0, [x8, #-0x28]
10000d930:     	ldp	x9, x10, [x22, #0x20]
10000d934:     	sub	x9, x9, w27, uxtw
10000d938:     	add	x10, x10, #0x1
10000d93c:     	stp	x9, x10, [x22, #0x20]
10000d940:     	ldr	x9, [sp, #0x150]
10000d944:     	stur	x9, [x8, #-0x8]
10000d948:     	stur	q1, [x8, #-0x38]
10000d94c:     	b	0x10000d60c <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x4f8>
10000d950:     	adrp	x2, 0x10005c000 <_write+0x10005c000>
10000d954:     	add	x2, x2, #0xe98
10000d958:     	mov	x0, x8
10000d95c:     	mov	w1, #0x4                ; =4
10000d960:     	bl	0x10004f1fc <__ZN4core9panicking18panic_bounds_check17hc9ab2de1b435fc32E>
10000d964:     	adrp	x2, 0x10005c000 <_write+0x10005c000>
10000d968:     	add	x2, x2, #0xe08
10000d96c:     	bl	0x10004f1fc <__ZN4core9panicking18panic_bounds_check17hc9ab2de1b435fc32E>
10000d970:     	adrp	x2, 0x10005c000 <_write+0x10005c000>
10000d974:     	add	x2, x2, #0xe80
10000d978:     	bl	0x10004f1fc <__ZN4core9panicking18panic_bounds_check17hc9ab2de1b435fc32E>
10000d97c:     	add	x0, x22, #0x10
10000d980:     	mov	x1, x22
10000d984:     	bl	0x10004d8a0 <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17hc4e569894c685c74E>
10000d988:     	ldp	x9, x8, [x22, #0x10]
10000d98c:     	and	x10, x9, x23
10000d990:     	ldr	x11, [x8, x10]
10000d994:     	ands	x11, x11, #0x8080808080808080
10000d998:     	b.ne	0x10000d9b8 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x8a4>
10000d99c:     	mov	w12, #0x8               ; =8
10000d9a0:     	add	x10, x10, x12
10000d9a4:     	and	x10, x10, x9
10000d9a8:     	ldr	x11, [x8, x10]
10000d9ac:     	add	x12, x12, #0x8
10000d9b0:     	ands	x11, x11, #0x8080808080808080
10000d9b4:     	b.eq	0x10000d9a0 <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x88c>
10000d9b8:     	rbit	x11, x11
10000d9bc:     	clz	x11, x11
10000d9c0:     	add	x10, x10, x11, lsr #3
10000d9c4:     	and	x10, x10, x9
10000d9c8:     	ldrsb	w11, [x8, x10]
10000d9cc:     	tbnz	w11, #0x1f, 0x10000d8dc <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x7c8>
10000d9d0:     	ldr	x10, [x8]
10000d9d4:     	and	x10, x10, #0x8080808080808080
10000d9d8:     	rbit	x10, x10
10000d9dc:     	clz	x10, x10
10000d9e0:     	lsr	x10, x10, #3
10000d9e4:     	b	0x10000d8dc <__ZN5sweep7results12score_cached17hfd6ddf711add50f7E+0x7c8>
10000d9e8:     	add	x0, x0, #0x1
10000d9ec:     	adrp	x2, 0x10005c000 <_write+0x10005c000>
10000d9f0:     	add	x2, x2, #0xe38
10000d9f4:     	bl	0x10004f1fc <__ZN4core9panicking18panic_bounds_check17hc9ab2de1b435fc32E>
10000d9f8:     	adrp	x2, 0x10005c000 <_write+0x10005c000>
10000d9fc:     	add	x2, x2, #0xe50
10000da00:     	mov	x1, x9
10000da04:     	bl	0x10004f1fc <__ZN4core9panicking18panic_bounds_check17hc9ab2de1b435fc32E>
10000da08:     	adrp	x2, 0x10005c000 <_write+0x10005c000>
10000da0c:     	add	x2, x2, #0xe68
10000da10:     	mov	x1, x8
10000da14:     	bl	0x10004f1fc <__ZN4core9panicking18panic_bounds_check17hc9ab2de1b435fc32E>
10000da18:     	adrp	x2, 0x10005c000 <_write+0x10005c000>
10000da1c:     	add	x2, x2, #0xe20
10000da20:     	mov	x0, x10
10000da24:     	mov	x1, x20
10000da28:     	bl	0x10004f1fc <__ZN4core9panicking18panic_bounds_check17hc9ab2de1b435fc32E>
