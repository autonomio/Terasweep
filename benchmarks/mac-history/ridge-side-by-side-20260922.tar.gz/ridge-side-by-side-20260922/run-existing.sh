#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PY=/tmp/limen-ridge-sfd-gjn81t22/venv/bin/python
TERA=/Users/mikkokotila/dev/Terasweep/target/terasweep
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
cd "$ROOT"
native() {
  echo "NATIVE repeat $1 $(date -u +%FT%TZ)"
  /usr/bin/time -lp "$PY" -m limen run "$ROOT/native-$1.yaml" > "$ROOT/logs/native-$1.stdout" 2> "$ROOT/logs/native-$1.time"
  cat "$ROOT/logs/native-$1.stdout"
  tail -19 "$ROOT/logs/native-$1.time"
}
tera() {
  echo "TERASWEEP repeat $1 $(date -u +%FT%TZ)"
  /usr/bin/time -lp "$TERA" "$ROOT/train.bin" "$ROOT/test.bin" "$ROOT/price.bin" "$ROOT/terasweep.json" 6 "$ROOT/terasweep/run-$1/summary.json" > "$ROOT/logs/terasweep-$1.stdout" 2> "$ROOT/logs/terasweep-$1.time"
  tail -19 "$ROOT/logs/terasweep-$1.time"
}
uptime
native 1; tera 1
tera 2; native 2
native 3; tera 3
tera 4; native 4
native 5; tera 5
uptime
