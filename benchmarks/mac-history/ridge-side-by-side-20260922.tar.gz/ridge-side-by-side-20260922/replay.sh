#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:?Supply an unused absolute output directory}"
PY="${LIMEN_PYTHON:-/tmp/limen-ridge-sfd-gjn81t22/venv/bin/python}"
TERA=/Users/mikkokotila/dev/Terasweep/target/terasweep
case "$OUT" in /*) ;; *) echo 'Output directory must be absolute' >&2; exit 2;; esac
cd "$ROOT"
shasum -a 256 -c input-sha256.txt
mkdir "$OUT"
mkdir "$OUT/terasweep"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
cd "$OUT"
/usr/bin/time -lp "$PY" -m limen run "$ROOT/native-repeatable.yaml" > native.stdout 2> native.time
cat native.stdout
/usr/bin/time -lp "$TERA" "$ROOT/train.bin" "$ROOT/test.bin" "$ROOT/price.bin" "$ROOT/terasweep.json" 6 "$OUT/terasweep/summary.json" > terasweep.stdout 2> terasweep.time
printf '\nNative results: %s/results/dev/native\nTerasweep results: %s/terasweep\n' "$OUT" "$OUT"
printf '\nWall times:\n'
grep '^real' native.time terasweep.time
