#!/usr/bin/env python3
"""Summarize a retained matched-chunk A/B log without dropping outliers."""
from __future__ import annotations
import json
import statistics
import sys
from pathlib import Path

def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit('usage: summarize.py <paired-results.jsonl> <summary.json>')
    rows = [json.loads(line) for line in Path(sys.argv[1]).read_text().splitlines()]
    values = {
        mode: {r['repeat']: r['seconds'] for r in rows
               if r['event'] == 'paired_timing' and r['mode'] == mode}
        for mode in (10, 12)
    }
    base, assembly = values[10], values[12]
    if not base or base.keys() != assembly.keys():
        raise ValueError('Missing or unmatched timing pairs')
    b, a = statistics.median(base.values()), statistics.median(assembly.values())
    result = {
        'scope': 'Scoring kernel only; sum of timed chunks per full job-set pass',
        'pairs': len(base), 'intrinsics_median_seconds': b,
        'handwritten_median_seconds': a, 'ratio_of_medians': b/a,
        'throughput_increase_pct': 100*(b/a-1),
        'time_reduction_pct': 100*(1-a/b),
        'paired_median_ratio': statistics.median(base[i]/assembly[i] for i in base),
        'assembly_wins': sum(assembly[i] < base[i] for i in base),
        'outliers_removed': 0,
    }
    text = json.dumps(result, indent=2) + '\n'
    Path(sys.argv[2]).write_text(text)
    print(text, end='')

if __name__ == '__main__':
    main()
