#!/usr/bin/env bash
# Isolated kernel benchmark, not a Rust/Limen performance substitute.
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$ROOT"
sha256sum --check checksums.txt
OUT=${1:-"$ROOT/replay-$(date -u +%Y%m%dT%H%M%SZ)"}
if [[ -e "$OUT" ]]; then printf 'Refusing to overwrite %s\n' "$OUT" >&2; exit 2; fi
mkdir -p "$OUT"
OUT=$(cd "$OUT" && pwd)
FLAGS=(-O3 -g -march=x86-64-v3 -ffp-contract=off -fno-fast-math -Wall -Wextra)
gcc "${FLAGS[@]}" -c src/raw_k16.c -o "$OUT/raw_gcc16.o"
clang "${FLAGS[@]}" -Dscore8_intrinsics=score8_clang16 -c src/raw_k16.c -o "$OUT/raw_clang16.o"
gcc "${FLAGS[@]}" -Dscore8_intrinsics=score8_gcc8 -c src/raw_k8.c -o "$OUT/raw_gcc8.o"
clang "${FLAGS[@]}" -Dscore8_intrinsics=score8_clang8 -c src/raw_k8.c -o "$OUT/raw_clang8.o"
clang "${FLAGS[@]}" -c src/original_mixed.c -o "$OUT/original_clang.o"
gcc "${FLAGS[@]}" src/probe.c "$OUT/raw_gcc16.o" "$OUT/raw_clang16.o" \
  "$OUT/raw_gcc8.o" "$OUT/raw_clang8.o" "$OUT/original_clang.o" \
  src/score8.S src/score8_gpr.S -lm -o "$OUT/probe"
mkdir "$OUT/validation" "$OUT/full-set" "$OUT/paired"
VALIDATE_ALL=1 BENCH_MODES=12 "$OUT/probe" "$ROOT/input/Terasweep/data" "$OUT/validation" 1 | tee "$OUT/validation/results.jsonl"
BENCH_MODES=9,10,12 INNER_LOOPS=4 "$OUT/probe" "$ROOT/input/Terasweep/data" "$OUT/full-set" 24 | tee "$OUT/full-set/results.jsonl"
PAIRED_CHUNKS=1 "$OUT/probe" "$ROOT/input/Terasweep/data" "$OUT/paired" 32 | tee "$OUT/paired/results.jsonl"
python3 "$ROOT/summarize.py" "$OUT/paired/results.jsonl" "$OUT/summary.json"
objdump -d -Mintel --disassemble=score8_asm_gpr "$OUT/probe" > "$OUT/handwritten.disassembly.txt"
printf '\nKernel experiment complete: %s\n' "$OUT"
