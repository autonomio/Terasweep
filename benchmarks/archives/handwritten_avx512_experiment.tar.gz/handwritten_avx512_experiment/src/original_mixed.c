#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stddef.h>
typedef struct { size_t n; uint8_t *tradable; double *entry,*cont; } Prices;
typedef struct {
 uint64_t signal_count; double eq_gross; int32_t entry_count,exit_count;
 uint64_t sharpe_count,cat_count[4]; double cat_sum_a[4],cat_sum_a2[4];
} Base;
__attribute__((target("avx512f"),noinline))
void v8_original_clang(const double*pred,const double*thresholds,const uint32_t*rules,size_t used,const Prices*pz,Base*out) {
 double adjusted[8];uint64_t neg[8],ab[8],inclusive[8];
 for(size_t l=0;l<8;l++){neg[l]=(rules[l]==2||rules[l]==3)?UINT64_MAX:0;ab[l]=(rules[l]>=4)?UINT64_MAX:0;inclusive[l]=(rules[l]==1||rules[l]==3||rules[l]==5)?UINT64_MAX:0;adjusted[l]=neg[l]?-thresholds[l]:thresholds[l];}

 __m512d zero=_mm512_setzero_pd(),one=_mm512_set1_pd(1.),t=_mm512_loadu_pd(adjusted),eq=one;
 __m512i sigcnt=_mm512_setzero_si512(),nc[4]={_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512()};
 __m512d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m512i oi=_mm512_set1_epi64(1);
 __mmask8 prev=0,last=0;uint64_t sharpe=0;size_t n=pz->n;
 __mmask8 negmask=0,abmask=0,incmask=0;for(int l=0;l<8;l++){if(neg[l])negmask|=1u<<l;if(ab[l])abmask|=1u<<l;if(inclusive[l])incmask|=1u<<l;}
 for(size_t i=0;i<n;i++){
  __m512d pv=_mm512_set1_pd(pred[i]);
  pv=_mm512_mask_mov_pd(pv,negmask,_mm512_castsi512_pd(_mm512_xor_si512(_mm512_castpd_si512(pv),_mm512_set1_epi64(INT64_MIN))));
  pv=_mm512_mask_mov_pd(pv,abmask,_mm512_castsi512_pd(_mm512_and_si512(_mm512_castpd_si512(pv),_mm512_set1_epi64(INT64_MAX))));
  __mmask8 sig=_mm512_cmp_pd_mask(pv,t,_CMP_GT_OQ)|(_mm512_cmp_pd_mask(pv,t,_CMP_EQ_OQ)&incmask);sigcnt=_mm512_mask_add_epi64(sigcnt,sig,sigcnt,oi);
  __mmask8 pos=i>0&&pz->tradable[i]?last:0;
  __mmask8 nextpos=i+1<n&&pz->tradable[i+1]?sig:0;
  __mmask8 en=((~(prev))&(pos)),co=((prev)&(pos)),ex=((~(nextpos))&(pos));
  __m512d gross=_mm512_mask_add_pd(zero,en,zero,_mm512_set1_pd(pz->entry[i]));
  gross=_mm512_mask_add_pd(gross,co,gross,_mm512_set1_pd(pz->cont[i]));
  __m512d a=_mm512_add_pd(one,gross);eq=_mm512_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m512d aa=_mm512_mul_pd(a,a);
   __mmask8 masks[4]={((__mmask8)~(((en)|(ex)))),((~(ex))&(en)),((~(en))&(ex)),((en)&(ex))};
   nc[0]=_mm512_mask_add_epi64(nc[0],masks[0],nc[0],oi);sums[0]=_mm512_mask_add_pd(sums[0],masks[0],sums[0],a);sq[0]=_mm512_mask_add_pd(sq[0],masks[0],sq[0],aa);
   nc[1]=_mm512_mask_add_epi64(nc[1],masks[1],nc[1],oi);sums[1]=_mm512_mask_add_pd(sums[1],masks[1],sums[1],a);sq[1]=_mm512_mask_add_pd(sq[1],masks[1],sq[1],aa);
   nc[2]=_mm512_mask_add_epi64(nc[2],masks[2],nc[2],oi);sums[2]=_mm512_mask_add_pd(sums[2],masks[2],sums[2],a);sq[2]=_mm512_mask_add_pd(sq[2],masks[2],sq[2],aa);
   nc[3]=_mm512_mask_add_epi64(nc[3],masks[3],nc[3],oi);sums[3]=_mm512_mask_add_pd(sums[3],masks[3],sums[3],a);sq[3]=_mm512_mask_add_pd(sq[3],masks[3],sq[3],aa);
  }prev=pos;last=sig;
 }
 uint64_t counts[8],cats[4][8];double equities[8],ss[4][8],qq[4][8];
 _mm512_storeu_si512((__m512i*)counts,sigcnt);_mm512_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm512_storeu_si512((__m512i*)cats[c],nc[c]);_mm512_storeu_pd(ss[c],sums[c]);_mm512_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}
