#ifndef SCORE_KERNEL_TYPES_H
#define SCORE_KERNEL_TYPES_H
#include <stdint.h>
#include <stddef.h>
/* The caller packs the same inputs and unpacks the same outputs for both kernels. */
typedef struct {
    double threshold[8];
    uint64_t sign_xor[8];
    uint64_t abs_and[8];
    uint64_t inclusive;
} Packed8;
typedef struct {
    uint64_t signal[8];
    double equity[8];
    uint64_t count[4][8];
    double sum[4][8];
    double square[4][8];
    uint64_t sharpe;
} Raw8;
_Static_assert(offsetof(Prices, cont)==24, "assembly price layout");
_Static_assert(offsetof(Packed8, inclusive) == 192, "assembly rule layout");
_Static_assert(offsetof(Raw8, sharpe) == 896, "assembly output layout");
void score8_asm(const double *pred, const Prices *prices,
                const Packed8 *rules, Raw8 *out);
void score8_intrinsics(const double *pred, const Prices *prices,
                       const Packed8 *rules, Raw8 *out);
#endif
