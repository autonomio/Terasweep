#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stddef.h>
typedef struct { size_t n; uint8_t *tradable; double *entry,*cont; } Prices;
#include "kernel_types.h"
/* Same operation graph and layout as the handwritten kernel. Explicit mask
 * intrinsics avoid deliberately accepting the original C's mask->GPR roundtrips.
 */
__attribute__((target("avx512f"),noinline))
void score8_intrinsics(const double *pred, const Prices *pz,
                       const Packed8 *r, Raw8 *out) {
    const __m512d zero=_mm512_setzero_pd(), one=_mm512_set1_pd(1.);
    const __m512i oi=_mm512_set1_epi64(1);
    const __m512d t=_mm512_loadu_pd(r->threshold);
    const __m512i sx=_mm512_loadu_si512(r->sign_xor), ab=_mm512_loadu_si512(r->abs_and);
    const __mmask16 inc=(__mmask16)r->inclusive;
    __m512d eq=one, sums[4]={zero,zero,zero,zero}, squares[4]={zero,zero,zero,zero};
    __m512i sigcnt=_mm512_setzero_si512();
    __m512i nc[4]={sigcnt,sigcnt,sigcnt,sigcnt};
    __mmask16 last=0,prev=0;
    uint64_t sharpe=0;
    const size_t n=pz->n;
    for(size_t i=0;i<n;i++) {
        __m512i pv=_mm512_castpd_si512(_mm512_set1_pd(pred[i]));
        pv=_mm512_and_si512(_mm512_xor_si512(pv,sx),ab);
        __mmask16 sig=_kor_mask16(_mm512_cmp_pd_mask(_mm512_castsi512_pd(pv),t,_CMP_GT_OQ),
                                  _mm512_mask_cmp_pd_mask((__mmask8)inc,_mm512_castsi512_pd(pv),t,_CMP_EQ_OQ));
        sigcnt=_mm512_mask_add_epi64(sigcnt,(__mmask8)sig,sigcnt,oi);
        __mmask16 pos=(i>0&&pz->tradable[i])?last:0;
        __mmask16 nextpos=(i+1<n&&pz->tradable[i+1])?sig:0;
        __mmask16 en=_kandn_mask16(prev,pos), co=_kand_mask16(prev,pos), ex=_kandn_mask16(nextpos,pos);
        __m512d gross=_mm512_mask_add_pd(zero,(__mmask8)en,zero,_mm512_set1_pd(pz->entry[i]));
        gross=_mm512_mask_add_pd(gross,(__mmask8)co,gross,_mm512_set1_pd(pz->cont[i]));
        __m512d a=_mm512_add_pd(one,gross);
        eq=_mm512_mul_pd(eq,a);
        if(i>0&&pz->tradable[i]) {
            sharpe++;
            __m512d aa=_mm512_mul_pd(a,a);
            __mmask16 mask[4]={_knot_mask16(_kor_mask16(en,ex)),_kandn_mask16(ex,en),_kandn_mask16(en,ex),_kand_mask16(en,ex)};
            for(int c=0;c<4;c++) {
                nc[c]=_mm512_mask_add_epi64(nc[c],(__mmask8)mask[c],nc[c],oi);
                sums[c]=_mm512_mask_add_pd(sums[c],(__mmask8)mask[c],sums[c],a);
                squares[c]=_mm512_mask_add_pd(squares[c],(__mmask8)mask[c],squares[c],aa);
            }
        }
        prev=pos;last=sig;
    }
    _mm512_storeu_si512(out->signal,sigcnt);
    _mm512_storeu_pd(out->equity,eq);
    for(int c=0;c<4;c++) {
        _mm512_storeu_si512(out->count[c],nc[c]);
        _mm512_storeu_pd(out->sum[c],sums[c]);
        _mm512_storeu_pd(out->square[c],squares[c]);
    }
    out->sharpe=sharpe;
}

