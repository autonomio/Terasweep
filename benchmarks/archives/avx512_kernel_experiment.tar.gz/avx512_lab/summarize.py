#!/usr/bin/env python3
"""Summarize measured scoring-kernel runs; do not infer full-sweep speedups."""
import argparse, hashlib, json, statistics
from pathlib import Path
NAMES={0:'C reference scorer',1:'Specialized scalar C',2:'AVX2 / one model and rule per batch',3:'AVX-512 / one model and rule per batch',4:'AVX2 / one model, mixed rules per batch',5:'AVX-512 / one model, mixed rules per batch'}
def summarize(path: Path) -> dict:
    rows=[json.loads(x) for x in path.read_text().splitlines() if x.strip()]
    measured=[]
    for mode,name in NAMES.items():
        samples=[x['seconds'] for x in rows if x['event']=='timing' and x['mode']==mode]
        if not samples: raise ValueError(f'No timings for mode {mode}')
        measured.append({'mode':mode,'name':name,'repeats':len(samples),'median_seconds':statistics.median(samples),'minimum_seconds':min(samples),'maximum_seconds':max(samples),'samples_seconds':samples})
    for row in measured: row['speedup_vs_c_reference']=measured[0]['median_seconds']/row['median_seconds']
    return {'scope':'C scoring-kernel experiment, not Rust end-to-end benchmark','timing_boundary':{'included':['batch construction inside score_jobs','threshold packing and rule masks','chronologically ordered base scoring','writing complete BaseScore outputs'],'excluded':['input reads','training-statistics computation','ridge fitting and predictions','one-million-row sampling','bounds classification','deduplication and sorting','fee/slippage application','winner selection','JSON/CSV artifact serialization']},'events':[x for x in rows if x['event']!='timing'],'modes':measured,'best_avx512_vs_best_avx2':measured[4]['median_seconds']/measured[5]['median_seconds'],'best_avx512_vs_specialized_scalar':measured[1]['median_seconds']/measured[5]['median_seconds'],'raw_log_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('log',type=Path);parser.add_argument('output',type=Path);a=parser.parse_args()
    report=summarize(a.log);a.output.write_text(json.dumps(report,indent=2)+'\n')
    for m in report['modes']: print(f"{m['name']}: {m['median_seconds']*1000:.3f} ms median, {m['speedup_vs_c_reference']:.3f}x vs C reference")
