/* Isolated scoring-kernel experiment, not a replacement Terasweep runner.
 * Scalar formulas are translated from the supplied ridge.rs/results.rs.
 * All observations come from the supplied frozen RIDGE001/PRICE001 files.
 * Compile without fast-math or FP contraction. */
#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sched.h>
#include <errno.h>
#include <inttypes.h>
#include <assert.h>
#define NOINLINE __attribute__((noinline))
#define ALWAYS __attribute__((always_inline)) inline
#define CONFIGS 2304

typedef struct { size_t n,d; double *x,*y; } Matrix;
typedef struct { size_t n; uint8_t *tradable; double *entry,*cont; } Prices;
typedef struct { size_t d; double *mean, ym, *gc,*hc,*gr,*hr; } Stats;
typedef struct { double *pred; double mae,lo,hi,alo,ahi; int failed; } Model;
typedef struct { uint32_t model,rule; double threshold; } Job;
typedef struct {
 uint64_t signal_count; double eq_gross; int32_t entry_count,exit_count;
 uint64_t sharpe_count,cat_count[4]; double cat_sum_a[4],cat_sum_a2[4];
} Base;
static double seconds(void) { struct timespec t; if(clock_gettime(CLOCK_MONOTONIC,&t)) {perror("clock");exit(2);} return t.tv_sec+t.tv_nsec*1e-9; }
static void *alloc(size_t n,size_t z) { void *p=calloc(n,z); if(!p){perror("calloc");exit(2);} return p; }
static void read_exact(FILE*f,void*p,size_t n) {if(fread(p,1,n,f)!=n){fprintf(stderr,"short input\n");exit(2);}}
static FILE *open_input(const char *dir,const char *name) {char p[4096];snprintf(p,sizeof p,"%s/%s",dir,name);FILE*f=fopen(p,"rb");if(!f){perror(p);exit(2);}return f;}
static Matrix matrix(const char*dir,const char*name) {
 FILE*f=open_input(dir,name); char magic[8];uint64_t dim[2];read_exact(f,magic,8);assert(!memcmp(magic,"RIDGE001",8));read_exact(f,dim,16);
 Matrix m={dim[0],dim[1],alloc(dim[0]*dim[1],8),alloc(dim[0],8)};read_exact(f,m.x,m.n*m.d*8);read_exact(f,m.y,m.n*8);assert(fgetc(f)==EOF);fclose(f);return m;
}
static Prices prices(const char*dir) {
 FILE*f=open_input(dir,"price.bin");char magic[8];uint64_t n;read_exact(f,magic,8);assert(!memcmp(magic,"PRICE001",8));read_exact(f,&n,8);
 double*o=alloc(n,8),*c=alloc(n,8);read_exact(f,o,n*8);read_exact(f,c,n*8);assert(fgetc(f)==EOF);fclose(f);
 Prices p={n,alloc(n,1),alloc(n,8),alloc(n,8)};
 for(size_t i=0;i<n;i++){p.tradable[i]=isfinite(o[i])&&isfinite(c[i])&&o[i]!=0.;if(p.tradable[i])p.entry[i]=(c[i]-o[i])/o[i];if(i>0&&isfinite(c[i-1])&&c[i-1]!=0.)p.cont[i]=c[i]/c[i-1]-1.;}
 free(o);free(c);return p;
}
static Stats stats(Matrix m) {
 size_t d=m.d;Stats s={d,alloc(d,8),0.,alloc(d*d,8),alloc(d,8),alloc(d*d,8),alloc(d,8)};
 for(size_t r=0;r<m.n;r++){s.ym+=m.y[r];for(size_t j=0;j<d;j++)s.mean[j]+=m.x[r*d+j];}
 double inv=1./m.n;s.ym*=inv;for(size_t j=0;j<d;j++)s.mean[j]*=inv;
 for(size_t r=0;r<m.n;r++){double yc=m.y[r]-s.ym;for(size_t i=0;i<d;i++){double raw=m.x[r*d+i],x=raw-s.mean[i];s.hc[i]+=x*yc;s.hr[i]+=raw*m.y[r];for(size_t j=0;j<=i;j++){s.gc[i*d+j]+=x*(m.x[r*d+j]-s.mean[j]);s.gr[i*d+j]+=raw*m.x[r*d+j];}}}
 return s;
}
static int solve(double*a,double*b,size_t n,double eps) {
 for(size_t r=0;r<n;r++)for(size_t c=0;c<=r;c++){double sum=a[r*n+c];for(size_t k=0;k<c;k++)sum-=a[r*n+k]*a[c*n+k];if(r==c){if(sum<=eps)return 0;a[r*n+c]=sqrt(sum);}else a[r*n+c]=sum/a[c*n+c];}
 for(size_t r=0;r<n;r++){double v=b[r];for(size_t c=0;c<r;c++)v-=a[r*n+c]*b[c];b[r]=v/a[r*n+r];}
 for(size_t r=n;r-->0;){double v=b[r];for(size_t c=r+1;c<n;c++)v-=a[c*n+r]*b[c];b[r]=v/a[r*n+r];}return 1;
}
static Model fit(Stats s,Matrix test,double alpha,int intercept,double eps) {
 size_t d=s.d;double*g=alloc(d*d,8),*h=alloc(d,8);memcpy(g,intercept?s.gc:s.gr,d*d*8);memcpy(h,intercept?s.hc:s.hr,d*8);
 for(size_t i=0;i<d;i++){g[i*d+i]+=alpha;for(size_t j=0;j<i;j++)g[j*d+i]=g[i*d+j];}
 Model m={.failed=1,.lo=INFINITY,.hi=-INFINITY,.alo=INFINITY,.ahi=0.};
 if(!solve(g,h,d,eps)){free(g);free(h);return m;}double b=0.;if(intercept){double sum=0.;for(size_t j=0;j<d;j++)sum+=s.mean[j]*h[j];b=s.ym-sum;}
 m.failed=0;m.pred=alloc(test.n,8);for(size_t r=0;r<test.n;r++){double p=b;for(size_t j=0;j<d;j++)p+=test.x[r*d+j]*h[j];assert(isfinite(p));m.pred[r]=p;m.mae+=fabs(p-test.y[r]);m.lo=fmin(m.lo,p);m.hi=fmax(m.hi,p);m.alo=fmin(m.alo,fabs(p));m.ahi=fmax(m.ahi,fabs(p));}m.mae/=test.n;free(g);free(h);return m;
}
static ALWAYS int active(double p,double t,int rule) {switch(rule){case 0:return p>t;case 1:return p>=t;case 2:return p<t;case 3:return p<=t;case 4:return fabs(p)>t;case 5:return fabs(p)>=t;default:abort();}}
NOINLINE static Base reference(const double*pred,double threshold,int rule,const Prices*p) {
 size_t n=p->n;Base b={.eq_gross=1.};for(size_t i=0;i<n;i++)if(active(pred[i],threshold,rule))b.signal_count++;
 int prev=0;for(size_t i=0;i<n;i++){
  int pos=i>0&&p->tradable[i]?active(pred[i-1],threshold,rule):0;
  int next=i+1<n&&p->tradable[i+1]?active(pred[i],threshold,rule):0;
  int entry=pos&&!prev,cont=pos&&prev,exit=pos&&!next;double gross=0.;
  if(entry){gross+=p->entry[i];b.entry_count++;}if(cont)gross+=p->cont[i];if(exit)b.exit_count++;
  double a=1.+gross;b.eq_gross*=a;if(i>0&&p->tradable[i]){int cat=entry|(exit<<1);b.sharpe_count++;b.cat_count[cat]++;b.cat_sum_a[cat]+=a;b.cat_sum_a2[cat]+=a*a;}prev=pos;
 }return b;
}
static uint64_t bits(double x){uint64_t b;memcpy(&b,&x,8);return b;}
static int equal(Base a,Base b){if(a.signal_count!=b.signal_count||bits(a.eq_gross)!=bits(b.eq_gross)||a.entry_count!=b.entry_count||a.exit_count!=b.exit_count||a.sharpe_count!=b.sharpe_count)return 0;for(int k=0;k<4;k++)if(a.cat_count[k]!=b.cat_count[k]||bits(a.cat_sum_a[k])!=bits(b.cat_sum_a[k])||bits(a.cat_sum_a2[k])!=bits(b.cat_sum_a2[k]))return 0;return 1;}
static uint64_t next(uint64_t*s){*s+=UINT64_C(0x9E3779B97F4A7C15);uint64_t v=*s;v=(v^(v>>30))*UINT64_C(0xBF58476D1CE4E5B9);v=(v^(v>>27))*UINT64_C(0x94D049BB133111EB);return v^(v>>31);}
static size_t index_rng(uint64_t*s,size_t n){return (size_t)(((__uint128_t)next(s)*n)>>64);}
static int constant(Model*m,int rule,double t){int off,on;switch(rule){case 0:off=m->hi<=t;on=m->lo>t;break;case 1:off=m->hi<t;on=m->lo>=t;break;case 2:off=m->lo>=t;on=m->hi<t;break;case 3:off=m->lo>t;on=m->hi<=t;break;case 4:off=m->ahi<=t;on=m->alo>t;break;default:off=m->ahi<t;on=m->alo>=t;}return off?0:on?1:2;}
static int jobcmp(const void*pa,const void*pb){const Job*a=pa,*b=pb;if(a->model!=b->model)return a->model<b->model?-1:1;if(a->rule!=b->rule)return a->rule<b->rule?-1:1;return (a->threshold>b->threshold)-(a->threshold<b->threshold);}
NOINLINE static Base specialized_0(const double*pred,double t,const Prices*pz) {
 Base b={.eq_gross=1.};int prev=0,last_signal=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){double p=pred[i];int sig=(p>t);b.signal_count+=sig;
 int pos=i>0&&pz->tradable[i]?last_signal:0,next=i+1<n&&pz->tradable[i+1]?sig:0;
 int entry=pos&&!prev,cont=pos&&prev,exit=pos&&!next;double gross=0.;
 if(entry){gross+=pz->entry[i];b.entry_count++;}if(cont)gross+=pz->cont[i];if(exit)b.exit_count++;
 double a=1.+gross;b.eq_gross*=a;if(i>0&&pz->tradable[i]){int c=entry|(exit<<1);b.sharpe_count++;b.cat_count[c]++;b.cat_sum_a[c]+=a;b.cat_sum_a2[c]+=a*a;}
 prev=pos;last_signal=sig;}return b;}
NOINLINE static Base specialized_1(const double*pred,double t,const Prices*pz) {
 Base b={.eq_gross=1.};int prev=0,last_signal=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){double p=pred[i];int sig=(p>=t);b.signal_count+=sig;
 int pos=i>0&&pz->tradable[i]?last_signal:0,next=i+1<n&&pz->tradable[i+1]?sig:0;
 int entry=pos&&!prev,cont=pos&&prev,exit=pos&&!next;double gross=0.;
 if(entry){gross+=pz->entry[i];b.entry_count++;}if(cont)gross+=pz->cont[i];if(exit)b.exit_count++;
 double a=1.+gross;b.eq_gross*=a;if(i>0&&pz->tradable[i]){int c=entry|(exit<<1);b.sharpe_count++;b.cat_count[c]++;b.cat_sum_a[c]+=a;b.cat_sum_a2[c]+=a*a;}
 prev=pos;last_signal=sig;}return b;}
NOINLINE static Base specialized_2(const double*pred,double t,const Prices*pz) {
 Base b={.eq_gross=1.};int prev=0,last_signal=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){double p=pred[i];int sig=(p<t);b.signal_count+=sig;
 int pos=i>0&&pz->tradable[i]?last_signal:0,next=i+1<n&&pz->tradable[i+1]?sig:0;
 int entry=pos&&!prev,cont=pos&&prev,exit=pos&&!next;double gross=0.;
 if(entry){gross+=pz->entry[i];b.entry_count++;}if(cont)gross+=pz->cont[i];if(exit)b.exit_count++;
 double a=1.+gross;b.eq_gross*=a;if(i>0&&pz->tradable[i]){int c=entry|(exit<<1);b.sharpe_count++;b.cat_count[c]++;b.cat_sum_a[c]+=a;b.cat_sum_a2[c]+=a*a;}
 prev=pos;last_signal=sig;}return b;}
NOINLINE static Base specialized_3(const double*pred,double t,const Prices*pz) {
 Base b={.eq_gross=1.};int prev=0,last_signal=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){double p=pred[i];int sig=(p<=t);b.signal_count+=sig;
 int pos=i>0&&pz->tradable[i]?last_signal:0,next=i+1<n&&pz->tradable[i+1]?sig:0;
 int entry=pos&&!prev,cont=pos&&prev,exit=pos&&!next;double gross=0.;
 if(entry){gross+=pz->entry[i];b.entry_count++;}if(cont)gross+=pz->cont[i];if(exit)b.exit_count++;
 double a=1.+gross;b.eq_gross*=a;if(i>0&&pz->tradable[i]){int c=entry|(exit<<1);b.sharpe_count++;b.cat_count[c]++;b.cat_sum_a[c]+=a;b.cat_sum_a2[c]+=a*a;}
 prev=pos;last_signal=sig;}return b;}
NOINLINE static Base specialized_4(const double*pred,double t,const Prices*pz) {
 Base b={.eq_gross=1.};int prev=0,last_signal=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){double p=pred[i];int sig=(fabs(p)>t);b.signal_count+=sig;
 int pos=i>0&&pz->tradable[i]?last_signal:0,next=i+1<n&&pz->tradable[i+1]?sig:0;
 int entry=pos&&!prev,cont=pos&&prev,exit=pos&&!next;double gross=0.;
 if(entry){gross+=pz->entry[i];b.entry_count++;}if(cont)gross+=pz->cont[i];if(exit)b.exit_count++;
 double a=1.+gross;b.eq_gross*=a;if(i>0&&pz->tradable[i]){int c=entry|(exit<<1);b.sharpe_count++;b.cat_count[c]++;b.cat_sum_a[c]+=a;b.cat_sum_a2[c]+=a*a;}
 prev=pos;last_signal=sig;}return b;}
NOINLINE static Base specialized_5(const double*pred,double t,const Prices*pz) {
 Base b={.eq_gross=1.};int prev=0,last_signal=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){double p=pred[i];int sig=(fabs(p)>=t);b.signal_count+=sig;
 int pos=i>0&&pz->tradable[i]?last_signal:0,next=i+1<n&&pz->tradable[i+1]?sig:0;
 int entry=pos&&!prev,cont=pos&&prev,exit=pos&&!next;double gross=0.;
 if(entry){gross+=pz->entry[i];b.entry_count++;}if(cont)gross+=pz->cont[i];if(exit)b.exit_count++;
 double a=1.+gross;b.eq_gross*=a;if(i>0&&pz->tradable[i]){int c=entry|(exit<<1);b.sharpe_count++;b.cat_count[c]++;b.cat_sum_a[c]+=a;b.cat_sum_a2[c]+=a*a;}
 prev=pos;last_signal=sig;}return b;}
typedef Base (*Scalar)(const double*,double,const Prices*);
static Scalar scalar_funcs[6]={specialized_0,specialized_1,specialized_2,specialized_3,specialized_4,specialized_5};

__attribute__((target("avx2"),noinline))
static void v4_0(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m256d zero=_mm256_setzero_pd(),one=_mm256_set1_pd(1.),t=_mm256_loadu_pd(thresholds),eq=one;
 __m256i sigcnt=_mm256_setzero_si256(),nc[4]={_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256()};
 __m256d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m256d all=_mm256_castsi256_pd(_mm256_set1_epi64x(-1));
 __m256d prev=_mm256_setzero_pd(),last=_mm256_setzero_pd();uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m256d pv=_mm256_set1_pd(pred[i]);
  __m256d sig=_mm256_cmp_pd(pv,t,_CMP_GT_OQ);sigcnt=_mm256_sub_epi64(sigcnt,_mm256_castpd_si256(sig));
  __m256d pos=i>0&&pz->tradable[i]?last:_mm256_setzero_pd();
  __m256d nextpos=i+1<n&&pz->tradable[i+1]?sig:_mm256_setzero_pd();
  __m256d en=_mm256_andnot_pd(prev,pos),co=_mm256_and_pd(prev,pos),ex=_mm256_andnot_pd(nextpos,pos);
  __m256d gross=_mm256_blendv_pd(zero,_mm256_add_pd(zero,_mm256_set1_pd(pz->entry[i])),en);
  gross=_mm256_blendv_pd(gross,_mm256_add_pd(gross,_mm256_set1_pd(pz->cont[i])),co);
  __m256d a=_mm256_add_pd(one,gross);eq=_mm256_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m256d aa=_mm256_mul_pd(a,a);
   __m256d masks[4]={_mm256_xor_pd(_mm256_or_pd(en,ex),all),_mm256_andnot_pd(ex,en),_mm256_andnot_pd(en,ex),_mm256_and_pd(en,ex)};
   nc[0]=_mm256_sub_epi64(nc[0],_mm256_castpd_si256(masks[0]));sums[0]=_mm256_blendv_pd(sums[0],_mm256_add_pd(sums[0],a),masks[0]);sq[0]=_mm256_blendv_pd(sq[0],_mm256_add_pd(sq[0],aa),masks[0]);
   nc[1]=_mm256_sub_epi64(nc[1],_mm256_castpd_si256(masks[1]));sums[1]=_mm256_blendv_pd(sums[1],_mm256_add_pd(sums[1],a),masks[1]);sq[1]=_mm256_blendv_pd(sq[1],_mm256_add_pd(sq[1],aa),masks[1]);
   nc[2]=_mm256_sub_epi64(nc[2],_mm256_castpd_si256(masks[2]));sums[2]=_mm256_blendv_pd(sums[2],_mm256_add_pd(sums[2],a),masks[2]);sq[2]=_mm256_blendv_pd(sq[2],_mm256_add_pd(sq[2],aa),masks[2]);
   nc[3]=_mm256_sub_epi64(nc[3],_mm256_castpd_si256(masks[3]));sums[3]=_mm256_blendv_pd(sums[3],_mm256_add_pd(sums[3],a),masks[3]);sq[3]=_mm256_blendv_pd(sq[3],_mm256_add_pd(sq[3],aa),masks[3]);
  }prev=pos;last=sig;
 }
 uint64_t counts[4],cats[4][4];double equities[4],ss[4][4],qq[4][4];
 _mm256_storeu_si256((__m256i*)counts,sigcnt);_mm256_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm256_storeu_si256((__m256i*)cats[c],nc[c]);_mm256_storeu_pd(ss[c],sums[c]);_mm256_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx2"),noinline))
static void v4_1(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m256d zero=_mm256_setzero_pd(),one=_mm256_set1_pd(1.),t=_mm256_loadu_pd(thresholds),eq=one;
 __m256i sigcnt=_mm256_setzero_si256(),nc[4]={_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256()};
 __m256d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m256d all=_mm256_castsi256_pd(_mm256_set1_epi64x(-1));
 __m256d prev=_mm256_setzero_pd(),last=_mm256_setzero_pd();uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m256d pv=_mm256_set1_pd(pred[i]);
  __m256d sig=_mm256_cmp_pd(pv,t,_CMP_GE_OQ);sigcnt=_mm256_sub_epi64(sigcnt,_mm256_castpd_si256(sig));
  __m256d pos=i>0&&pz->tradable[i]?last:_mm256_setzero_pd();
  __m256d nextpos=i+1<n&&pz->tradable[i+1]?sig:_mm256_setzero_pd();
  __m256d en=_mm256_andnot_pd(prev,pos),co=_mm256_and_pd(prev,pos),ex=_mm256_andnot_pd(nextpos,pos);
  __m256d gross=_mm256_blendv_pd(zero,_mm256_add_pd(zero,_mm256_set1_pd(pz->entry[i])),en);
  gross=_mm256_blendv_pd(gross,_mm256_add_pd(gross,_mm256_set1_pd(pz->cont[i])),co);
  __m256d a=_mm256_add_pd(one,gross);eq=_mm256_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m256d aa=_mm256_mul_pd(a,a);
   __m256d masks[4]={_mm256_xor_pd(_mm256_or_pd(en,ex),all),_mm256_andnot_pd(ex,en),_mm256_andnot_pd(en,ex),_mm256_and_pd(en,ex)};
   nc[0]=_mm256_sub_epi64(nc[0],_mm256_castpd_si256(masks[0]));sums[0]=_mm256_blendv_pd(sums[0],_mm256_add_pd(sums[0],a),masks[0]);sq[0]=_mm256_blendv_pd(sq[0],_mm256_add_pd(sq[0],aa),masks[0]);
   nc[1]=_mm256_sub_epi64(nc[1],_mm256_castpd_si256(masks[1]));sums[1]=_mm256_blendv_pd(sums[1],_mm256_add_pd(sums[1],a),masks[1]);sq[1]=_mm256_blendv_pd(sq[1],_mm256_add_pd(sq[1],aa),masks[1]);
   nc[2]=_mm256_sub_epi64(nc[2],_mm256_castpd_si256(masks[2]));sums[2]=_mm256_blendv_pd(sums[2],_mm256_add_pd(sums[2],a),masks[2]);sq[2]=_mm256_blendv_pd(sq[2],_mm256_add_pd(sq[2],aa),masks[2]);
   nc[3]=_mm256_sub_epi64(nc[3],_mm256_castpd_si256(masks[3]));sums[3]=_mm256_blendv_pd(sums[3],_mm256_add_pd(sums[3],a),masks[3]);sq[3]=_mm256_blendv_pd(sq[3],_mm256_add_pd(sq[3],aa),masks[3]);
  }prev=pos;last=sig;
 }
 uint64_t counts[4],cats[4][4];double equities[4],ss[4][4],qq[4][4];
 _mm256_storeu_si256((__m256i*)counts,sigcnt);_mm256_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm256_storeu_si256((__m256i*)cats[c],nc[c]);_mm256_storeu_pd(ss[c],sums[c]);_mm256_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx2"),noinline))
static void v4_2(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m256d zero=_mm256_setzero_pd(),one=_mm256_set1_pd(1.),t=_mm256_loadu_pd(thresholds),eq=one;
 __m256i sigcnt=_mm256_setzero_si256(),nc[4]={_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256()};
 __m256d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m256d all=_mm256_castsi256_pd(_mm256_set1_epi64x(-1));
 __m256d prev=_mm256_setzero_pd(),last=_mm256_setzero_pd();uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m256d pv=_mm256_set1_pd(pred[i]);
  __m256d sig=_mm256_cmp_pd(pv,t,_CMP_LT_OQ);sigcnt=_mm256_sub_epi64(sigcnt,_mm256_castpd_si256(sig));
  __m256d pos=i>0&&pz->tradable[i]?last:_mm256_setzero_pd();
  __m256d nextpos=i+1<n&&pz->tradable[i+1]?sig:_mm256_setzero_pd();
  __m256d en=_mm256_andnot_pd(prev,pos),co=_mm256_and_pd(prev,pos),ex=_mm256_andnot_pd(nextpos,pos);
  __m256d gross=_mm256_blendv_pd(zero,_mm256_add_pd(zero,_mm256_set1_pd(pz->entry[i])),en);
  gross=_mm256_blendv_pd(gross,_mm256_add_pd(gross,_mm256_set1_pd(pz->cont[i])),co);
  __m256d a=_mm256_add_pd(one,gross);eq=_mm256_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m256d aa=_mm256_mul_pd(a,a);
   __m256d masks[4]={_mm256_xor_pd(_mm256_or_pd(en,ex),all),_mm256_andnot_pd(ex,en),_mm256_andnot_pd(en,ex),_mm256_and_pd(en,ex)};
   nc[0]=_mm256_sub_epi64(nc[0],_mm256_castpd_si256(masks[0]));sums[0]=_mm256_blendv_pd(sums[0],_mm256_add_pd(sums[0],a),masks[0]);sq[0]=_mm256_blendv_pd(sq[0],_mm256_add_pd(sq[0],aa),masks[0]);
   nc[1]=_mm256_sub_epi64(nc[1],_mm256_castpd_si256(masks[1]));sums[1]=_mm256_blendv_pd(sums[1],_mm256_add_pd(sums[1],a),masks[1]);sq[1]=_mm256_blendv_pd(sq[1],_mm256_add_pd(sq[1],aa),masks[1]);
   nc[2]=_mm256_sub_epi64(nc[2],_mm256_castpd_si256(masks[2]));sums[2]=_mm256_blendv_pd(sums[2],_mm256_add_pd(sums[2],a),masks[2]);sq[2]=_mm256_blendv_pd(sq[2],_mm256_add_pd(sq[2],aa),masks[2]);
   nc[3]=_mm256_sub_epi64(nc[3],_mm256_castpd_si256(masks[3]));sums[3]=_mm256_blendv_pd(sums[3],_mm256_add_pd(sums[3],a),masks[3]);sq[3]=_mm256_blendv_pd(sq[3],_mm256_add_pd(sq[3],aa),masks[3]);
  }prev=pos;last=sig;
 }
 uint64_t counts[4],cats[4][4];double equities[4],ss[4][4],qq[4][4];
 _mm256_storeu_si256((__m256i*)counts,sigcnt);_mm256_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm256_storeu_si256((__m256i*)cats[c],nc[c]);_mm256_storeu_pd(ss[c],sums[c]);_mm256_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx2"),noinline))
static void v4_3(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m256d zero=_mm256_setzero_pd(),one=_mm256_set1_pd(1.),t=_mm256_loadu_pd(thresholds),eq=one;
 __m256i sigcnt=_mm256_setzero_si256(),nc[4]={_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256()};
 __m256d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m256d all=_mm256_castsi256_pd(_mm256_set1_epi64x(-1));
 __m256d prev=_mm256_setzero_pd(),last=_mm256_setzero_pd();uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m256d pv=_mm256_set1_pd(pred[i]);
  __m256d sig=_mm256_cmp_pd(pv,t,_CMP_LE_OQ);sigcnt=_mm256_sub_epi64(sigcnt,_mm256_castpd_si256(sig));
  __m256d pos=i>0&&pz->tradable[i]?last:_mm256_setzero_pd();
  __m256d nextpos=i+1<n&&pz->tradable[i+1]?sig:_mm256_setzero_pd();
  __m256d en=_mm256_andnot_pd(prev,pos),co=_mm256_and_pd(prev,pos),ex=_mm256_andnot_pd(nextpos,pos);
  __m256d gross=_mm256_blendv_pd(zero,_mm256_add_pd(zero,_mm256_set1_pd(pz->entry[i])),en);
  gross=_mm256_blendv_pd(gross,_mm256_add_pd(gross,_mm256_set1_pd(pz->cont[i])),co);
  __m256d a=_mm256_add_pd(one,gross);eq=_mm256_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m256d aa=_mm256_mul_pd(a,a);
   __m256d masks[4]={_mm256_xor_pd(_mm256_or_pd(en,ex),all),_mm256_andnot_pd(ex,en),_mm256_andnot_pd(en,ex),_mm256_and_pd(en,ex)};
   nc[0]=_mm256_sub_epi64(nc[0],_mm256_castpd_si256(masks[0]));sums[0]=_mm256_blendv_pd(sums[0],_mm256_add_pd(sums[0],a),masks[0]);sq[0]=_mm256_blendv_pd(sq[0],_mm256_add_pd(sq[0],aa),masks[0]);
   nc[1]=_mm256_sub_epi64(nc[1],_mm256_castpd_si256(masks[1]));sums[1]=_mm256_blendv_pd(sums[1],_mm256_add_pd(sums[1],a),masks[1]);sq[1]=_mm256_blendv_pd(sq[1],_mm256_add_pd(sq[1],aa),masks[1]);
   nc[2]=_mm256_sub_epi64(nc[2],_mm256_castpd_si256(masks[2]));sums[2]=_mm256_blendv_pd(sums[2],_mm256_add_pd(sums[2],a),masks[2]);sq[2]=_mm256_blendv_pd(sq[2],_mm256_add_pd(sq[2],aa),masks[2]);
   nc[3]=_mm256_sub_epi64(nc[3],_mm256_castpd_si256(masks[3]));sums[3]=_mm256_blendv_pd(sums[3],_mm256_add_pd(sums[3],a),masks[3]);sq[3]=_mm256_blendv_pd(sq[3],_mm256_add_pd(sq[3],aa),masks[3]);
  }prev=pos;last=sig;
 }
 uint64_t counts[4],cats[4][4];double equities[4],ss[4][4],qq[4][4];
 _mm256_storeu_si256((__m256i*)counts,sigcnt);_mm256_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm256_storeu_si256((__m256i*)cats[c],nc[c]);_mm256_storeu_pd(ss[c],sums[c]);_mm256_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx2"),noinline))
static void v4_4(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m256d zero=_mm256_setzero_pd(),one=_mm256_set1_pd(1.),t=_mm256_loadu_pd(thresholds),eq=one;
 __m256i sigcnt=_mm256_setzero_si256(),nc[4]={_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256()};
 __m256d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m256d all=_mm256_castsi256_pd(_mm256_set1_epi64x(-1));
 __m256d prev=_mm256_setzero_pd(),last=_mm256_setzero_pd();uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m256d pv=_mm256_set1_pd(pred[i]);pv=_mm256_castsi256_pd(_mm256_and_si256(_mm256_castpd_si256(pv),_mm256_set1_epi64x(INT64_MAX)));
  __m256d sig=_mm256_cmp_pd(pv,t,_CMP_GT_OQ);sigcnt=_mm256_sub_epi64(sigcnt,_mm256_castpd_si256(sig));
  __m256d pos=i>0&&pz->tradable[i]?last:_mm256_setzero_pd();
  __m256d nextpos=i+1<n&&pz->tradable[i+1]?sig:_mm256_setzero_pd();
  __m256d en=_mm256_andnot_pd(prev,pos),co=_mm256_and_pd(prev,pos),ex=_mm256_andnot_pd(nextpos,pos);
  __m256d gross=_mm256_blendv_pd(zero,_mm256_add_pd(zero,_mm256_set1_pd(pz->entry[i])),en);
  gross=_mm256_blendv_pd(gross,_mm256_add_pd(gross,_mm256_set1_pd(pz->cont[i])),co);
  __m256d a=_mm256_add_pd(one,gross);eq=_mm256_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m256d aa=_mm256_mul_pd(a,a);
   __m256d masks[4]={_mm256_xor_pd(_mm256_or_pd(en,ex),all),_mm256_andnot_pd(ex,en),_mm256_andnot_pd(en,ex),_mm256_and_pd(en,ex)};
   nc[0]=_mm256_sub_epi64(nc[0],_mm256_castpd_si256(masks[0]));sums[0]=_mm256_blendv_pd(sums[0],_mm256_add_pd(sums[0],a),masks[0]);sq[0]=_mm256_blendv_pd(sq[0],_mm256_add_pd(sq[0],aa),masks[0]);
   nc[1]=_mm256_sub_epi64(nc[1],_mm256_castpd_si256(masks[1]));sums[1]=_mm256_blendv_pd(sums[1],_mm256_add_pd(sums[1],a),masks[1]);sq[1]=_mm256_blendv_pd(sq[1],_mm256_add_pd(sq[1],aa),masks[1]);
   nc[2]=_mm256_sub_epi64(nc[2],_mm256_castpd_si256(masks[2]));sums[2]=_mm256_blendv_pd(sums[2],_mm256_add_pd(sums[2],a),masks[2]);sq[2]=_mm256_blendv_pd(sq[2],_mm256_add_pd(sq[2],aa),masks[2]);
   nc[3]=_mm256_sub_epi64(nc[3],_mm256_castpd_si256(masks[3]));sums[3]=_mm256_blendv_pd(sums[3],_mm256_add_pd(sums[3],a),masks[3]);sq[3]=_mm256_blendv_pd(sq[3],_mm256_add_pd(sq[3],aa),masks[3]);
  }prev=pos;last=sig;
 }
 uint64_t counts[4],cats[4][4];double equities[4],ss[4][4],qq[4][4];
 _mm256_storeu_si256((__m256i*)counts,sigcnt);_mm256_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm256_storeu_si256((__m256i*)cats[c],nc[c]);_mm256_storeu_pd(ss[c],sums[c]);_mm256_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx2"),noinline))
static void v4_5(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m256d zero=_mm256_setzero_pd(),one=_mm256_set1_pd(1.),t=_mm256_loadu_pd(thresholds),eq=one;
 __m256i sigcnt=_mm256_setzero_si256(),nc[4]={_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256(),_mm256_setzero_si256()};
 __m256d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m256d all=_mm256_castsi256_pd(_mm256_set1_epi64x(-1));
 __m256d prev=_mm256_setzero_pd(),last=_mm256_setzero_pd();uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m256d pv=_mm256_set1_pd(pred[i]);pv=_mm256_castsi256_pd(_mm256_and_si256(_mm256_castpd_si256(pv),_mm256_set1_epi64x(INT64_MAX)));
  __m256d sig=_mm256_cmp_pd(pv,t,_CMP_GE_OQ);sigcnt=_mm256_sub_epi64(sigcnt,_mm256_castpd_si256(sig));
  __m256d pos=i>0&&pz->tradable[i]?last:_mm256_setzero_pd();
  __m256d nextpos=i+1<n&&pz->tradable[i+1]?sig:_mm256_setzero_pd();
  __m256d en=_mm256_andnot_pd(prev,pos),co=_mm256_and_pd(prev,pos),ex=_mm256_andnot_pd(nextpos,pos);
  __m256d gross=_mm256_blendv_pd(zero,_mm256_add_pd(zero,_mm256_set1_pd(pz->entry[i])),en);
  gross=_mm256_blendv_pd(gross,_mm256_add_pd(gross,_mm256_set1_pd(pz->cont[i])),co);
  __m256d a=_mm256_add_pd(one,gross);eq=_mm256_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m256d aa=_mm256_mul_pd(a,a);
   __m256d masks[4]={_mm256_xor_pd(_mm256_or_pd(en,ex),all),_mm256_andnot_pd(ex,en),_mm256_andnot_pd(en,ex),_mm256_and_pd(en,ex)};
   nc[0]=_mm256_sub_epi64(nc[0],_mm256_castpd_si256(masks[0]));sums[0]=_mm256_blendv_pd(sums[0],_mm256_add_pd(sums[0],a),masks[0]);sq[0]=_mm256_blendv_pd(sq[0],_mm256_add_pd(sq[0],aa),masks[0]);
   nc[1]=_mm256_sub_epi64(nc[1],_mm256_castpd_si256(masks[1]));sums[1]=_mm256_blendv_pd(sums[1],_mm256_add_pd(sums[1],a),masks[1]);sq[1]=_mm256_blendv_pd(sq[1],_mm256_add_pd(sq[1],aa),masks[1]);
   nc[2]=_mm256_sub_epi64(nc[2],_mm256_castpd_si256(masks[2]));sums[2]=_mm256_blendv_pd(sums[2],_mm256_add_pd(sums[2],a),masks[2]);sq[2]=_mm256_blendv_pd(sq[2],_mm256_add_pd(sq[2],aa),masks[2]);
   nc[3]=_mm256_sub_epi64(nc[3],_mm256_castpd_si256(masks[3]));sums[3]=_mm256_blendv_pd(sums[3],_mm256_add_pd(sums[3],a),masks[3]);sq[3]=_mm256_blendv_pd(sq[3],_mm256_add_pd(sq[3],aa),masks[3]);
  }prev=pos;last=sig;
 }
 uint64_t counts[4],cats[4][4];double equities[4],ss[4][4],qq[4][4];
 _mm256_storeu_si256((__m256i*)counts,sigcnt);_mm256_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm256_storeu_si256((__m256i*)cats[c],nc[c]);_mm256_storeu_pd(ss[c],sums[c]);_mm256_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}
typedef void (*V4)(const double*,const double*,size_t,const Prices*,Base*);
static V4 funcs4[6]={v4_0,v4_1,v4_2,v4_3,v4_4,v4_5};

__attribute__((target("avx512f"),noinline))
static void v8_0(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m512d zero=_mm512_setzero_pd(),one=_mm512_set1_pd(1.),t=_mm512_loadu_pd(thresholds),eq=one;
 __m512i sigcnt=_mm512_setzero_si512(),nc[4]={_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512()};
 __m512d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m512i oi=_mm512_set1_epi64(1);
 __mmask8 prev=0,last=0;uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m512d pv=_mm512_set1_pd(pred[i]);
  __mmask8 sig=_mm512_cmp_pd_mask(pv,t,_CMP_GT_OQ);sigcnt=_mm512_mask_add_epi64(sigcnt,sig,sigcnt,oi);
  __mmask8 pos=i>0&&pz->tradable[i]?last:0;
  __mmask8 nextpos=i+1<n&&pz->tradable[i+1]?sig:0;
  __mmask8 en=((~(prev))&(pos)),co=((prev)&(pos)),ex=((~(nextpos))&(pos));
  __m512d gross=_mm512_mask_add_pd(zero,en,zero,_mm512_set1_pd(pz->entry[i]));
  gross=_mm512_mask_add_pd(gross,co,gross,_mm512_set1_pd(pz->cont[i]));
  __m512d a=_mm512_add_pd(one,gross);eq=_mm512_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m512d aa=_mm512_mul_pd(a,a);
   __mmask8 masks[4]={((__mmask8)~(((en)|(ex)))),((~(ex))&(en)),((~(en))&(ex)),((en)&(ex))};
   nc[0]=_mm512_mask_add_epi64(nc[0],masks[0],nc[0],oi);sums[0]=_mm512_mask_add_pd(sums[0],masks[0],sums[0],a);sq[0]=_mm512_mask_add_pd(sq[0],masks[0],sq[0],aa);
   nc[1]=_mm512_mask_add_epi64(nc[1],masks[1],nc[1],oi);sums[1]=_mm512_mask_add_pd(sums[1],masks[1],sums[1],a);sq[1]=_mm512_mask_add_pd(sq[1],masks[1],sq[1],aa);
   nc[2]=_mm512_mask_add_epi64(nc[2],masks[2],nc[2],oi);sums[2]=_mm512_mask_add_pd(sums[2],masks[2],sums[2],a);sq[2]=_mm512_mask_add_pd(sq[2],masks[2],sq[2],aa);
   nc[3]=_mm512_mask_add_epi64(nc[3],masks[3],nc[3],oi);sums[3]=_mm512_mask_add_pd(sums[3],masks[3],sums[3],a);sq[3]=_mm512_mask_add_pd(sq[3],masks[3],sq[3],aa);
  }prev=pos;last=sig;
 }
 uint64_t counts[8],cats[4][8];double equities[8],ss[4][8],qq[4][8];
 _mm512_storeu_si512((__m512i*)counts,sigcnt);_mm512_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm512_storeu_si512((__m512i*)cats[c],nc[c]);_mm512_storeu_pd(ss[c],sums[c]);_mm512_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx512f"),noinline))
static void v8_1(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m512d zero=_mm512_setzero_pd(),one=_mm512_set1_pd(1.),t=_mm512_loadu_pd(thresholds),eq=one;
 __m512i sigcnt=_mm512_setzero_si512(),nc[4]={_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512()};
 __m512d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m512i oi=_mm512_set1_epi64(1);
 __mmask8 prev=0,last=0;uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m512d pv=_mm512_set1_pd(pred[i]);
  __mmask8 sig=_mm512_cmp_pd_mask(pv,t,_CMP_GE_OQ);sigcnt=_mm512_mask_add_epi64(sigcnt,sig,sigcnt,oi);
  __mmask8 pos=i>0&&pz->tradable[i]?last:0;
  __mmask8 nextpos=i+1<n&&pz->tradable[i+1]?sig:0;
  __mmask8 en=((~(prev))&(pos)),co=((prev)&(pos)),ex=((~(nextpos))&(pos));
  __m512d gross=_mm512_mask_add_pd(zero,en,zero,_mm512_set1_pd(pz->entry[i]));
  gross=_mm512_mask_add_pd(gross,co,gross,_mm512_set1_pd(pz->cont[i]));
  __m512d a=_mm512_add_pd(one,gross);eq=_mm512_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m512d aa=_mm512_mul_pd(a,a);
   __mmask8 masks[4]={((__mmask8)~(((en)|(ex)))),((~(ex))&(en)),((~(en))&(ex)),((en)&(ex))};
   nc[0]=_mm512_mask_add_epi64(nc[0],masks[0],nc[0],oi);sums[0]=_mm512_mask_add_pd(sums[0],masks[0],sums[0],a);sq[0]=_mm512_mask_add_pd(sq[0],masks[0],sq[0],aa);
   nc[1]=_mm512_mask_add_epi64(nc[1],masks[1],nc[1],oi);sums[1]=_mm512_mask_add_pd(sums[1],masks[1],sums[1],a);sq[1]=_mm512_mask_add_pd(sq[1],masks[1],sq[1],aa);
   nc[2]=_mm512_mask_add_epi64(nc[2],masks[2],nc[2],oi);sums[2]=_mm512_mask_add_pd(sums[2],masks[2],sums[2],a);sq[2]=_mm512_mask_add_pd(sq[2],masks[2],sq[2],aa);
   nc[3]=_mm512_mask_add_epi64(nc[3],masks[3],nc[3],oi);sums[3]=_mm512_mask_add_pd(sums[3],masks[3],sums[3],a);sq[3]=_mm512_mask_add_pd(sq[3],masks[3],sq[3],aa);
  }prev=pos;last=sig;
 }
 uint64_t counts[8],cats[4][8];double equities[8],ss[4][8],qq[4][8];
 _mm512_storeu_si512((__m512i*)counts,sigcnt);_mm512_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm512_storeu_si512((__m512i*)cats[c],nc[c]);_mm512_storeu_pd(ss[c],sums[c]);_mm512_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx512f"),noinline))
static void v8_2(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m512d zero=_mm512_setzero_pd(),one=_mm512_set1_pd(1.),t=_mm512_loadu_pd(thresholds),eq=one;
 __m512i sigcnt=_mm512_setzero_si512(),nc[4]={_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512()};
 __m512d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m512i oi=_mm512_set1_epi64(1);
 __mmask8 prev=0,last=0;uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m512d pv=_mm512_set1_pd(pred[i]);
  __mmask8 sig=_mm512_cmp_pd_mask(pv,t,_CMP_LT_OQ);sigcnt=_mm512_mask_add_epi64(sigcnt,sig,sigcnt,oi);
  __mmask8 pos=i>0&&pz->tradable[i]?last:0;
  __mmask8 nextpos=i+1<n&&pz->tradable[i+1]?sig:0;
  __mmask8 en=((~(prev))&(pos)),co=((prev)&(pos)),ex=((~(nextpos))&(pos));
  __m512d gross=_mm512_mask_add_pd(zero,en,zero,_mm512_set1_pd(pz->entry[i]));
  gross=_mm512_mask_add_pd(gross,co,gross,_mm512_set1_pd(pz->cont[i]));
  __m512d a=_mm512_add_pd(one,gross);eq=_mm512_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m512d aa=_mm512_mul_pd(a,a);
   __mmask8 masks[4]={((__mmask8)~(((en)|(ex)))),((~(ex))&(en)),((~(en))&(ex)),((en)&(ex))};
   nc[0]=_mm512_mask_add_epi64(nc[0],masks[0],nc[0],oi);sums[0]=_mm512_mask_add_pd(sums[0],masks[0],sums[0],a);sq[0]=_mm512_mask_add_pd(sq[0],masks[0],sq[0],aa);
   nc[1]=_mm512_mask_add_epi64(nc[1],masks[1],nc[1],oi);sums[1]=_mm512_mask_add_pd(sums[1],masks[1],sums[1],a);sq[1]=_mm512_mask_add_pd(sq[1],masks[1],sq[1],aa);
   nc[2]=_mm512_mask_add_epi64(nc[2],masks[2],nc[2],oi);sums[2]=_mm512_mask_add_pd(sums[2],masks[2],sums[2],a);sq[2]=_mm512_mask_add_pd(sq[2],masks[2],sq[2],aa);
   nc[3]=_mm512_mask_add_epi64(nc[3],masks[3],nc[3],oi);sums[3]=_mm512_mask_add_pd(sums[3],masks[3],sums[3],a);sq[3]=_mm512_mask_add_pd(sq[3],masks[3],sq[3],aa);
  }prev=pos;last=sig;
 }
 uint64_t counts[8],cats[4][8];double equities[8],ss[4][8],qq[4][8];
 _mm512_storeu_si512((__m512i*)counts,sigcnt);_mm512_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm512_storeu_si512((__m512i*)cats[c],nc[c]);_mm512_storeu_pd(ss[c],sums[c]);_mm512_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx512f"),noinline))
static void v8_3(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m512d zero=_mm512_setzero_pd(),one=_mm512_set1_pd(1.),t=_mm512_loadu_pd(thresholds),eq=one;
 __m512i sigcnt=_mm512_setzero_si512(),nc[4]={_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512()};
 __m512d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m512i oi=_mm512_set1_epi64(1);
 __mmask8 prev=0,last=0;uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m512d pv=_mm512_set1_pd(pred[i]);
  __mmask8 sig=_mm512_cmp_pd_mask(pv,t,_CMP_LE_OQ);sigcnt=_mm512_mask_add_epi64(sigcnt,sig,sigcnt,oi);
  __mmask8 pos=i>0&&pz->tradable[i]?last:0;
  __mmask8 nextpos=i+1<n&&pz->tradable[i+1]?sig:0;
  __mmask8 en=((~(prev))&(pos)),co=((prev)&(pos)),ex=((~(nextpos))&(pos));
  __m512d gross=_mm512_mask_add_pd(zero,en,zero,_mm512_set1_pd(pz->entry[i]));
  gross=_mm512_mask_add_pd(gross,co,gross,_mm512_set1_pd(pz->cont[i]));
  __m512d a=_mm512_add_pd(one,gross);eq=_mm512_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m512d aa=_mm512_mul_pd(a,a);
   __mmask8 masks[4]={((__mmask8)~(((en)|(ex)))),((~(ex))&(en)),((~(en))&(ex)),((en)&(ex))};
   nc[0]=_mm512_mask_add_epi64(nc[0],masks[0],nc[0],oi);sums[0]=_mm512_mask_add_pd(sums[0],masks[0],sums[0],a);sq[0]=_mm512_mask_add_pd(sq[0],masks[0],sq[0],aa);
   nc[1]=_mm512_mask_add_epi64(nc[1],masks[1],nc[1],oi);sums[1]=_mm512_mask_add_pd(sums[1],masks[1],sums[1],a);sq[1]=_mm512_mask_add_pd(sq[1],masks[1],sq[1],aa);
   nc[2]=_mm512_mask_add_epi64(nc[2],masks[2],nc[2],oi);sums[2]=_mm512_mask_add_pd(sums[2],masks[2],sums[2],a);sq[2]=_mm512_mask_add_pd(sq[2],masks[2],sq[2],aa);
   nc[3]=_mm512_mask_add_epi64(nc[3],masks[3],nc[3],oi);sums[3]=_mm512_mask_add_pd(sums[3],masks[3],sums[3],a);sq[3]=_mm512_mask_add_pd(sq[3],masks[3],sq[3],aa);
  }prev=pos;last=sig;
 }
 uint64_t counts[8],cats[4][8];double equities[8],ss[4][8],qq[4][8];
 _mm512_storeu_si512((__m512i*)counts,sigcnt);_mm512_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm512_storeu_si512((__m512i*)cats[c],nc[c]);_mm512_storeu_pd(ss[c],sums[c]);_mm512_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx512f"),noinline))
static void v8_4(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m512d zero=_mm512_setzero_pd(),one=_mm512_set1_pd(1.),t=_mm512_loadu_pd(thresholds),eq=one;
 __m512i sigcnt=_mm512_setzero_si512(),nc[4]={_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512()};
 __m512d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m512i oi=_mm512_set1_epi64(1);
 __mmask8 prev=0,last=0;uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m512d pv=_mm512_set1_pd(pred[i]);pv=_mm512_castsi512_pd(_mm512_and_si512(_mm512_castpd_si512(pv),_mm512_set1_epi64(INT64_MAX)));
  __mmask8 sig=_mm512_cmp_pd_mask(pv,t,_CMP_GT_OQ);sigcnt=_mm512_mask_add_epi64(sigcnt,sig,sigcnt,oi);
  __mmask8 pos=i>0&&pz->tradable[i]?last:0;
  __mmask8 nextpos=i+1<n&&pz->tradable[i+1]?sig:0;
  __mmask8 en=((~(prev))&(pos)),co=((prev)&(pos)),ex=((~(nextpos))&(pos));
  __m512d gross=_mm512_mask_add_pd(zero,en,zero,_mm512_set1_pd(pz->entry[i]));
  gross=_mm512_mask_add_pd(gross,co,gross,_mm512_set1_pd(pz->cont[i]));
  __m512d a=_mm512_add_pd(one,gross);eq=_mm512_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m512d aa=_mm512_mul_pd(a,a);
   __mmask8 masks[4]={((__mmask8)~(((en)|(ex)))),((~(ex))&(en)),((~(en))&(ex)),((en)&(ex))};
   nc[0]=_mm512_mask_add_epi64(nc[0],masks[0],nc[0],oi);sums[0]=_mm512_mask_add_pd(sums[0],masks[0],sums[0],a);sq[0]=_mm512_mask_add_pd(sq[0],masks[0],sq[0],aa);
   nc[1]=_mm512_mask_add_epi64(nc[1],masks[1],nc[1],oi);sums[1]=_mm512_mask_add_pd(sums[1],masks[1],sums[1],a);sq[1]=_mm512_mask_add_pd(sq[1],masks[1],sq[1],aa);
   nc[2]=_mm512_mask_add_epi64(nc[2],masks[2],nc[2],oi);sums[2]=_mm512_mask_add_pd(sums[2],masks[2],sums[2],a);sq[2]=_mm512_mask_add_pd(sq[2],masks[2],sq[2],aa);
   nc[3]=_mm512_mask_add_epi64(nc[3],masks[3],nc[3],oi);sums[3]=_mm512_mask_add_pd(sums[3],masks[3],sums[3],a);sq[3]=_mm512_mask_add_pd(sq[3],masks[3],sq[3],aa);
  }prev=pos;last=sig;
 }
 uint64_t counts[8],cats[4][8];double equities[8],ss[4][8],qq[4][8];
 _mm512_storeu_si512((__m512i*)counts,sigcnt);_mm512_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm512_storeu_si512((__m512i*)cats[c],nc[c]);_mm512_storeu_pd(ss[c],sums[c]);_mm512_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}

__attribute__((target("avx512f"),noinline))
static void v8_5(const double*pred,const double*thresholds,size_t used,const Prices*pz,Base*out) {
 __m512d zero=_mm512_setzero_pd(),one=_mm512_set1_pd(1.),t=_mm512_loadu_pd(thresholds),eq=one;
 __m512i sigcnt=_mm512_setzero_si512(),nc[4]={_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512(),_mm512_setzero_si512()};
 __m512d sums[4]={zero,zero,zero,zero},sq[4]={zero,zero,zero,zero};
 __m512i oi=_mm512_set1_epi64(1);
 __mmask8 prev=0,last=0;uint64_t sharpe=0;size_t n=pz->n;
 for(size_t i=0;i<n;i++){
  __m512d pv=_mm512_set1_pd(pred[i]);pv=_mm512_castsi512_pd(_mm512_and_si512(_mm512_castpd_si512(pv),_mm512_set1_epi64(INT64_MAX)));
  __mmask8 sig=_mm512_cmp_pd_mask(pv,t,_CMP_GE_OQ);sigcnt=_mm512_mask_add_epi64(sigcnt,sig,sigcnt,oi);
  __mmask8 pos=i>0&&pz->tradable[i]?last:0;
  __mmask8 nextpos=i+1<n&&pz->tradable[i+1]?sig:0;
  __mmask8 en=((~(prev))&(pos)),co=((prev)&(pos)),ex=((~(nextpos))&(pos));
  __m512d gross=_mm512_mask_add_pd(zero,en,zero,_mm512_set1_pd(pz->entry[i]));
  gross=_mm512_mask_add_pd(gross,co,gross,_mm512_set1_pd(pz->cont[i]));
  __m512d a=_mm512_add_pd(one,gross);eq=_mm512_mul_pd(eq,a);
  if(i>0&&pz->tradable[i]){
   sharpe++;__m512d aa=_mm512_mul_pd(a,a);
   __mmask8 masks[4]={((__mmask8)~(((en)|(ex)))),((~(ex))&(en)),((~(en))&(ex)),((en)&(ex))};
   nc[0]=_mm512_mask_add_epi64(nc[0],masks[0],nc[0],oi);sums[0]=_mm512_mask_add_pd(sums[0],masks[0],sums[0],a);sq[0]=_mm512_mask_add_pd(sq[0],masks[0],sq[0],aa);
   nc[1]=_mm512_mask_add_epi64(nc[1],masks[1],nc[1],oi);sums[1]=_mm512_mask_add_pd(sums[1],masks[1],sums[1],a);sq[1]=_mm512_mask_add_pd(sq[1],masks[1],sq[1],aa);
   nc[2]=_mm512_mask_add_epi64(nc[2],masks[2],nc[2],oi);sums[2]=_mm512_mask_add_pd(sums[2],masks[2],sums[2],a);sq[2]=_mm512_mask_add_pd(sq[2],masks[2],sq[2],aa);
   nc[3]=_mm512_mask_add_epi64(nc[3],masks[3],nc[3],oi);sums[3]=_mm512_mask_add_pd(sums[3],masks[3],sums[3],a);sq[3]=_mm512_mask_add_pd(sq[3],masks[3],sq[3],aa);
  }prev=pos;last=sig;
 }
 uint64_t counts[8],cats[4][8];double equities[8],ss[4][8],qq[4][8];
 _mm512_storeu_si512((__m512i*)counts,sigcnt);_mm512_storeu_pd(equities,eq);
 for(int c=0;c<4;c++){_mm512_storeu_si512((__m512i*)cats[c],nc[c]);_mm512_storeu_pd(ss[c],sums[c]);_mm512_storeu_pd(qq[c],sq[c]);}
 for(size_t l=0;l<used;l++){Base b={.signal_count=counts[l],.eq_gross=equities[l],.sharpe_count=sharpe};
 for(int c=0;c<4;c++){b.cat_count[c]=cats[c][l];b.cat_sum_a[c]=ss[c][l];b.cat_sum_a2[c]=qq[c][l];}
 b.entry_count=b.cat_count[1]+b.cat_count[3];b.exit_count=b.cat_count[2]+b.cat_count[3];out[l]=b;}
}
typedef void (*V8)(const double*,const double*,size_t,const Prices*,Base*);
static V8 funcs8[6]={v8_0,v8_1,v8_2,v8_3,v8_4,v8_5};

static void score_jobs(int mode,Model*models,Job*jobs,size_t count,Prices*p,Base*out) {
 if(mode<2){for(size_t j=0;j<count;j++){Job q=jobs[j];out[j]=mode?scalar_funcs[q.rule](models[q.model].pred,q.threshold,p):reference(models[q.model].pred,q.threshold,q.rule,p);}return;}
 size_t width=mode==2?4:8;
 for(size_t j=0;j<count;){size_t k=1;while(k<width&&j+k<count&&jobs[j+k].model==jobs[j].model&&jobs[j+k].rule==jobs[j].rule)k++;
 double ts[8];for(size_t l=0;l<width;l++)ts[l]=jobs[j+(l<k?l:0)].threshold;
 if(mode==2)funcs4[jobs[j].rule](models[jobs[j].model].pred,ts,k,p,out+j);else funcs8[jobs[j].rule](models[jobs[j].model].pred,ts,k,p,out+j);j+=k;}
}
static uint64_t fingerprint(Base*out,size_t n) {uint64_t v=0;for(size_t i=0;i<n;i++){v^=bits(out[i].eq_gross)+UINT64_C(0x9e3779b97f4a7c15)+(v<<6)+(v>>2);v^=out[i].signal_count;}return v;}
static void write_outputs(const char*dir,const char*name,Base*b,size_t n){char path[4096];snprintf(path,sizeof path,"%s/%s",dir,name);FILE*f=fopen(path,"wb");if(!f){perror(path);exit(2);}if(fwrite(b,sizeof* b,n,f)!=n){perror("write");exit(2);}fclose(f);}
int main(int argc,char**argv){
 if(argc!=4){fprintf(stderr,"usage: %s <data-dir> <output-dir> <repetitions>\n",argv[0]);return 2;}
 setvbuf(stdout,NULL,_IOLBF,0);__builtin_cpu_init();if(!__builtin_cpu_supports("avx512f")||!__builtin_cpu_supports("avx2")){fprintf(stderr,"AVX2/AVX512F required\n");return 2;}
 assert(sizeof(Base)==128);int reps=atoi(argv[3]);assert(reps>0&&reps<=31);
 cpu_set_t available;assert(!sched_getaffinity(0,sizeof available,&available));int pinned=-1;for(int i=0;i<CPU_SETSIZE;i++)if(CPU_ISSET(i,&available)){pinned=i;break;}cpu_set_t one;CPU_ZERO(&one);CPU_SET(pinned,&one);assert(!sched_setaffinity(0,sizeof one,&one));
 printf("{\"event\":\"environment\",\"cpu\":%d,\"avx2\":true,\"avx512f\":true,\"compiler\":\"%s\"}\n",pinned,__VERSION__);
 Matrix train=matrix(argv[1],"train.bin"),test=matrix(argv[1],"test.bin");Prices p=prices(argv[1]);assert(train.d==test.d&&test.n==p.n);
 double begin=seconds();Stats st=stats(train);Model*models=alloc(CONFIGS,sizeof(Model));double eps[3]={1e-14,1e-12,1e-10};size_t failed=0;
 for(size_t a=0;a<384;a++){double t=(double)a/383.;double alpha=pow(10.,-8.+16.*t);for(int i=0;i<2;i++)for(int e=0;e<3;e++){size_t k=(a*2+i)*3+e;models[k]=fit(st,test,alpha,i==0,eps[e]);failed+=models[k].failed;}}
 printf("{\"event\":\"preparation\",\"seconds\":%.9f,\"train_rows\":%zu,\"features\":%zu,\"test_rows\":%zu,\"failed_models\":%zu}\n",seconds()-begin,train.n,train.d,test.n,failed);
 double signed_t[401],abs_t[201],v=-1.;for(int i=0;i<401;i++,v+=.005)signed_t[i]=round(v*1e12)/1e12;v=0.;for(int i=0;i<201;i++,v+=.005)abs_t[i]=round(v*1e12)/1e12;
 uint8_t*seen=alloc(CONFIGS*6*401,1);Job*all=alloc(1000000,sizeof(Job)),*mixed=alloc(1000000,sizeof(Job));size_t na=0,nm=0,states[3]={0},failed_rows=0;
 for(uint64_t id=0;id<1000000;id++){uint64_t s=id;s=UINT64_C(20260514)^next(&s);int rule=index_rng(&s,6);size_t ai=index_rng(&s,384),ti=index_rng(&s,rule>=4?201:401),ii=index_rng(&s,2),ei=index_rng(&s,3);(void)index_rng(&s,13);(void)index_rng(&s,13);size_t model=(ai*2+ii)*3+ei;if(models[model].failed){failed_rows++;continue;}size_t key=(model*6+rule)*401+ti;if(seen[key])continue;seen[key]=1;double threshold=rule>=4?abs_t[ti]:signed_t[ti];Job q={model,rule,threshold};all[na++]=q;int c=constant(&models[model],rule,threshold);states[c]++;if(c==2)mixed[nm++]=q;}
 qsort(mixed,nm,sizeof(Job),jobcmp);qsort(all,na,sizeof(Job),jobcmp);
 size_t batch4=0,batch8=0;for(size_t i=0;i<nm;){size_t end=i+1;while(end<nm&&mixed[end].model==mixed[i].model&&mixed[end].rule==mixed[i].rule)end++;batch4+=(end-i+3)/4;batch8+=(end-i+7)/8;i=end;}
 printf("{\"event\":\"jobs\",\"failed_rows\":%zu,\"unique\":%zu,\"off\":%zu,\"on\":%zu,\"mixed\":%zu,\"lane_utilization_avx2\":%.9f,\"lane_utilization_avx512\":%.9f}\n",failed_rows,na,states[0],states[1],states[2],(double)nm/(4*batch4),(double)nm/(8*batch8));
 Base*expected=alloc(nm,sizeof(Base)),*out=alloc(nm,sizeof(Base));begin=seconds();score_jobs(0,models,mixed,nm,&p,expected);printf("{\"event\":\"reference_first_pass\",\"seconds\":%.9f,\"fingerprint\":\"%016" PRIx64 "\"}\n",seconds()-begin,fingerprint(expected,nm));
 for(int mode=1;mode<4;mode++){score_jobs(mode,models,mixed,nm,&p,out);for(size_t j=0;j<nm;j++)if(!equal(expected[j],out[j])){fprintf(stderr,"MISMATCH mode %d job %zu model %u rule %u threshold %.17g\n",mode,j,mixed[j].model,mixed[j].rule,mixed[j].threshold);return 1;}printf("{\"event\":\"bitwise_validation\",\"mode\":%d,\"jobs\":%zu,\"pass\":true}\n",mode,nm);}
 // Real-data boundary tests: threshold at and one ULP either side of selected actual predictions.
 size_t boundary_checks=0;for(size_t model=0;model<CONFIGS;model+=37){if(models[model].failed)continue;for(int rule=0;rule<6;rule++)for(size_t idx=0;idx<p.n;idx+=127){double t=rule>=4?fabs(models[model].pred[idx]):models[model].pred[idx];double ts[8]={t,nextafter(t,-INFINITY),nextafter(t,INFINITY),0.,-0.,models[model].lo,models[model].hi,models[model].ahi};Base want[8],got[8];for(int l=0;l<8;l++)want[l]=reference(models[model].pred,ts[l],rule,&p);funcs8[rule](models[model].pred,ts,8,&p,got);for(int l=0;l<8;l++){if(!equal(want[l],got[l])){fprintf(stderr,"boundary mismatch model %zu rule %d lane %d\n",model,rule,l);return 1;}boundary_checks++;}for(int b=0;b<2;b++){funcs4[rule](models[model].pred,ts+4*b,4,&p,got+4*b);}for(int l=0;l<8;l++)assert(equal(want[l],got[l]));}}
 printf("{\"event\":\"boundary_validation\",\"jobs_per_simd_mode\":%zu,\"pass\":true}\n",boundary_checks);
 write_outputs(argv[2],"reference-scores.bin",expected,nm);
 uint64_t checksum=0;for(int rep=0;rep<reps;rep++)for(int k=0;k<4;k++){int mode=(rep+k)%4;begin=seconds();score_jobs(mode,models,mixed,nm,&p,out);double elapsed=seconds()-begin;uint64_t fp=fingerprint(out,nm);checksum^=fp;printf("{\"event\":\"timing\",\"repeat\":%d,\"mode\":%d,\"seconds\":%.9f,\"jobs\":%zu,\"fingerprint\":\"%016" PRIx64 "\"}\n",rep+1,mode,elapsed,nm,fp);}
 printf("{\"event\":\"done\",\"checksum\":\"%016" PRIx64 "\"}\n",checksum);return 0;
}
