#!/usr/bin/env bash
# Replay this C kernel experiment only. Does not build or modify Terasweep.
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$ROOT"
sha256sum --check input-sha256.txt
OUT=${1:-"$ROOT/replay-$(date -u +%Y%m%dT%H%M%SZ)"}
if [[ -e "$OUT" ]]; then printf 'Refusing to overwrite %s\n' "$OUT" >&2; exit 2; fi
mkdir -p "$OUT"
OUT=$(cd "$OUT" && pwd)
gcc -O3 -g -march=x86-64-v3 -ffp-contract=off -fno-fast-math -Wall -Wextra \
    "$ROOT/kernel_probe.c" -lm -o "$OUT/kernel_probe"
"$OUT/kernel_probe" "$ROOT/input/Terasweep/data" "$OUT" 12 | tee "$OUT/probe.jsonl"
python3 "$ROOT/summarize.py" "$OUT/probe.jsonl" "$OUT/summary.json"
printf '\nEvidence written to %s\n' "$OUT"
