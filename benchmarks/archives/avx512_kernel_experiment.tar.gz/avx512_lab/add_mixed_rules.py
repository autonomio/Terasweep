from pathlib import Path
p=Path(__file__).resolve().parent/'kernel_probe.c'
s=p.read_text()
blocks=[]
for w in (4,8):
 start=s.index('__attribute__((target("'+('avx2' if w==4 else 'avx512f')+'"),noinline))\nstatic void v'+str(w)+'_0(')
 end=s.index('\n__attribute__',start+10)
 if end<0: raise ValueError('end')
 f=s[start:end]
 f=f.replace(f'v{w}_0(',f'v{w}_mixed(').replace('const double*thresholds,size_t used','const double*thresholds,const uint32_t*rules,size_t used')
 prefix=''' double adjusted[8];uint64_t neg[8],ab[8],inclusive[8];
 for(size_t l=0;l<WIDTH;l++){neg[l]=(rules[l]==2||rules[l]==3)?UINT64_MAX:0;ab[l]=(rules[l]>=4)?UINT64_MAX:0;inclusive[l]=(rules[l]==1||rules[l]==3||rules[l]==5)?UINT64_MAX:0;adjusted[l]=neg[l]?-thresholds[l]:thresholds[l];}
'''.replace('WIDTH',str(w))
 pos=f.index('\n ')
 f=f[:pos]+'\n'+prefix+f[pos:]
 f=f.replace(f'_mm{w*64}_loadu_pd(thresholds)',f'_mm{w*64}_loadu_pd(adjusted)')
 if w==4:
  prefix=''' __m256d negmask=_mm256_castsi256_pd(_mm256_loadu_si256((const __m256i*)neg));
 __m256d abmask=_mm256_castsi256_pd(_mm256_loadu_si256((const __m256i*)ab));
 __m256d incmask=_mm256_castsi256_pd(_mm256_loadu_si256((const __m256i*)inclusive));
'''
  op='''pv=_mm256_blendv_pd(pv,_mm256_xor_pd(pv,_mm256_set1_pd(-0.)),negmask);
  pv=_mm256_blendv_pd(pv,_mm256_andnot_pd(_mm256_set1_pd(-0.),pv),abmask);
  __m256d sig=_mm256_or_pd(_mm256_cmp_pd(pv,t,_CMP_GT_OQ),_mm256_and_pd(incmask,_mm256_cmp_pd(pv,t,_CMP_EQ_OQ)));'''
 else:
  prefix=''' __mmask8 negmask=0,abmask=0,incmask=0;for(int l=0;l<8;l++){if(neg[l])negmask|=1u<<l;if(ab[l])abmask|=1u<<l;if(inclusive[l])incmask|=1u<<l;}
'''
  op='''pv=_mm512_mask_mov_pd(pv,negmask,_mm512_castsi512_pd(_mm512_xor_si512(_mm512_castpd_si512(pv),_mm512_set1_epi64(INT64_MIN))));
  pv=_mm512_mask_mov_pd(pv,abmask,_mm512_castsi512_pd(_mm512_and_si512(_mm512_castpd_si512(pv),_mm512_set1_epi64(INT64_MAX))));
  __mmask8 sig=_mm512_cmp_pd_mask(pv,t,_CMP_GT_OQ)|(_mm512_cmp_pd_mask(pv,t,_CMP_EQ_OQ)&incmask);'''
 f=f.replace(f' for(size_t i=0;i<n;i++){{',prefix+' for(size_t i=0;i<n;i++){')
 old=('__m256d sig=_mm256_cmp_pd(pv,t,_CMP_GT_OQ);' if w==4 else '__mmask8 sig=_mm512_cmp_pd_mask(pv,t,_CMP_GT_OQ);')
 assert old in f
 f=f.replace(old,op)
 blocks.append(f)
s=s.replace('static void score_jobs(', '\n'.join(blocks)+'\nstatic void score_jobs(')
s=s.replace('size_t width=mode==2?4:8;','size_t width=(mode==2||mode==4)?4:8;')
s=s.replace('&&jobs[j+k].rule==jobs[j].rule','&&(mode>=4||jobs[j+k].rule==jobs[j].rule)')
s=s.replace('double ts[8];for(size_t l=0;l<width;l++)ts[l]=jobs[j+(l<k?l:0)].threshold;','double ts[8];uint32_t rules[8];for(size_t l=0;l<width;l++){ts[l]=jobs[j+(l<k?l:0)].threshold;rules[l]=jobs[j+(l<k?l:0)].rule;}')
s=s.replace('if(mode==2)funcs4', 'if(mode==4)v4_mixed(models[jobs[j].model].pred,ts,rules,k,p,out+j);else if(mode==5)v8_mixed(models[jobs[j].model].pred,ts,rules,k,p,out+j);else if(mode==2)funcs4')
s=s.replace('mode<4;mode++','mode<6;mode++').replace('k<4;k++){int mode=(rep+k)%4','k<6;k++){int mode=(rep+k)%6')
# More boundary checks for rule-mixed SIMD functions, using the existing real predictions.
needle='printf("{\\"event\\":\\"boundary_validation'
idx=s.index(needle)
more='''for(size_t model=0;model<CONFIGS;model+=37){if(models[model].failed)continue;for(size_t idx=0;idx<p.n;idx+=127){double ts[8];uint32_t rr[8];Base want[8],got[8];for(int l=0;l<8;l++){rr[l]=l%6;double t=models[model].pred[idx];if(rr[l]>=4)t=fabs(t);ts[l]=l%3==0?t:nextafter(t,l%3==1?-INFINITY:INFINITY);want[l]=reference(models[model].pred,ts[l],rr[l],&p);}v8_mixed(models[model].pred,ts,rr,8,&p,got);for(int l=0;l<8;l++)assert(equal(want[l],got[l]));for(int b=0;b<2;b++)v4_mixed(models[model].pred,ts+4*b,rr+4*b,4,&p,got+4*b);for(int l=0;l<8;l++)assert(equal(want[l],got[l]));}}
 '''
s=s[:idx]+more+s[idx:]
# Report utilization of cross-rule grouping separately.
pos=s.index(' Base*expected=')
stat=''' size_t flexible4=0,flexible8=0;for(size_t i=0;i<nm;){size_t end=i+1;while(end<nm&&mixed[end].model==mixed[i].model)end++;flexible4+=(end-i+3)/4;flexible8+=(end-i+7)/8;i=end;}
 printf("{\\"event\\":\\"flexible_batches\\",\\"lane_utilization_avx2\\":%.9f,\\"lane_utilization_avx512\\":%.9f}\\n",(double)nm/(4*flexible4),(double)nm/(8*flexible8));
'''
s=s[:pos]+stat+s[pos:]
p.write_text(s)
